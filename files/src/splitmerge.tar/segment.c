#include "splitmerge.h"
#include <stdio.h>



/* TME 8 exercice 1.3 */
void split_segment( GNode *qt, unsigned char *buf, int dimx) {

  /* à compléter */

}



/* TME 9 exercice 7 */
void merge_segment( GSList *regions, unsigned char *buf, int dimx) {
  
  /* à compléter */
}

