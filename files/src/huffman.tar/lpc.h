
void mat2lpc( char *out, unsigned char *in, int dimx, int dimy);
void lpc2mat( unsigned char *out, char *in, int dimx, int dimy);

