#include <inrimage/image.h>
#include "huffman.h"


int main( int argc, char **argv) {
  struct image *nf;
  Fort_int lfmt[9];
  unsigned char *buf, *buf_enc;
  char nom[128];
  float *his;
  char **table;

  inr_init( argc, argv, "", "", "");

  /* Lecture image 1 octet */
  infileopt( nom);
  nf = image_( nom, "e", "", lfmt);
  if( BSIZE != 1 || TYPE != FIXE)
    imerror( 6, "Codage non accepte\n");
  buf = (unsigned char*) i_malloc(DIMX*DIMY);
  c_lect( nf, DIMY, buf);
  fermnf_(&nf);
  

  /* Appel a histn() */




  /* Calcul table de Huffman */




  /* encodage image */



  /* decodage image */




  /* ecriture image */
  outfileopt(nom);
  nf = image_( nom, "c", "", lfmt);
  c_ecr( nf, DIMY, buf);
  fermnf_(&nf);


}
