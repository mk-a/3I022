/*
 * INRIMAGE
 * Copyright (c) 1988 -- 2006
 * Institut National de Recherche en Informatique et Automatique
 * Domaine de Voluceau-Rocquencourt  B.P. 105  78153 LE CHESNAY cedex
 *
 * Toute distribution de ce logiciel doit etre soumise a l'autorisation
 * de l'INRIA et comporter le present avis de copyright.
 *
 * $Id$
 */


/* define pour la portabilite */
#ifndef INR_image_included   /* ignore if already included */
#define INR_image_included

#ifdef interdata
typedef char CHAR;
#else
typedef unsigned char CHAR;
#endif

#include <errno.h>

#ifdef __ksr1__
#define HAS_PTHREADS
#include <pthread.h>
typedef int int4;
typedef unsigned int u_int4;
typedef int float4;
typedef long Fort_int;
typedef unsigned long u_Fort_int;
typedef unsigned long t_aligned;
#define SUBPG_SIZE 128
#define _SHARED __shared
#define _PRIVATE __private
#else  /* not KSR1 */
#define _SHARED
#define _PRIVATE
#ifdef __alpha
typedef int int4;
typedef unsigned int u_int4;
typedef int float4;
typedef long Fort_int;
typedef unsigned long u_Fort_int;
typedef unsigned long t_aligned;
#define SUBPG_SIZE (sizeof(t_aligned))
#else  /* not ALPHA nor KSR1 */
#ifdef __x86_64__
typedef int int4;
typedef unsigned int u_int4;
typedef float float4;  
typedef int Fort_int;  /* integer g77 est 32 bits */
typedef unsigned int u_Fort_int;
typedef unsigned long t_aligned;
#define SUBPG_SIZE (sizeof(t_aligned))
#else /* not Alpha nor Ksr1 nor x86_64 */
typedef long int4;
typedef unsigned long u_int4;
typedef float float4;
typedef int Fort_int;
typedef unsigned int u_Fort_int;
typedef unsigned long t_aligned;
#define SUBPG_SIZE (sizeof(t_aligned))
#endif /* x86_64 */
#endif /* alpha  */
#endif /* ksr1   */

struct typsz {
	Fort_int sz_float;
	Fort_int sz_Fort_int;
	Fort_int sz_long;
	Fort_int sz_int;
	Fort_int sz_int4;
	Fort_int sz_ptr;
	Fort_int sz_aligned;
};

/*********************************** */
typedef struct nf_fmt {
	Fort_int lfmt[9]; /* format principal */
	Fort_int offsets[3]; /* de'calages d'origine en X,Y,Z */
	Fort_int maille; /* maillage : 0=rect., 1= hexgonal */
	float bias;   /* constante a rajouter a chaque pixel (virg. fixe) */
	float scale;  /* coeff multiplicatif (virg. fixe) quand il n'est pas 2**n */
}  NF_fmt;

/* structure image */
typedef struct image {
#ifdef HAS_PTHREADS
	align128 pthread_mutex_t nf_lock;
#endif
	char *nom;	/* nom du fichier ou < si stdin ou > si stdout */
	int fd;		/* file descriptor */
	Fort_int lfmt[9];	/* format */
	int no_ligne;	/* numero ligne courante */
        int hors_tout; /* Nombre d'octets par lignes sur fichier (avec padding) */
	int bits_lig;		/* nb de bits par ligne (sans padding) */
	short f_type;   /* file type voir FL_... */
	short maille;   /* maillage : 0=rect., 1=hexa */
	int byte_pnt;	/* pointeur sur le byte courant du fichier*/
	short i_version; /*  version : <=0 means undef. see IV_.. */
	short hdr_stat;    /* etat du descripteur voir ST_... */
	int desc_size;  /* size of header in bytes */
	char *hdr_data; /* adresse du bloc contenant le header */
	char **hdr_lines;	/* ptr vers tables des adresses des lignes ascii du header */
	   /* Note : pour INR3 et Visilog, il s'agit de la partie ascii du header 
	      le dernier pointeur pointe vers limite utile et l'avant-dernier
	      vers la place libre de fin de header (=dernier si pas de place) */
	int hdrl_size;   /* size of hdr4 */
	int hdr_nlines;  /* nb de lignes de hdr4 */
	short first_hist;  /* index in hdr_lines of 1st history line */
	short last_hist;   /* index in hdr_lines of last history line */
	short hnum1, hnum2; /* number of 1st and last history record */
	short float_typ; /* type du flottant ou type de cpu */
	short flt_conv;  /* -1 = conversion impossible , 0= conv. non necessaire, 1= convertir en lecture
			    -1 est remplace par 0 a la 1ere lecture */
	short data_msbfirst;  /* 1= Msb first,  -1= inconnu */
	short swap_needed;  /*  -1 = on ne sait pas, 1= swap data necessaire Short, 2= swap long */
	int cnv_ovf;	/* nb of overflows/underflows during float conversion */
	int offsets[3];    /* x0, y0, z0 */
	float bias;   /* constante a rajouter a chaque pixel (virg. fixe) */
	float scale;  /* coeff multiplicatif (virg. fixe) quand il n'est pas 2**n
		       0 = a ignorer */
	unsigned short x_active;  /* contient 0x4163 si nf actif */
	unsigned short x_nftab;   /* indice de nf dans la table */
} Inrimage;

#define NF_ACTIVE 0x4163
/* definitions de hdr_stat */
#define HST_TOWRITE 1
#define HST_HISTSET 4   /* history set */
#define HST_HIST2SET 8  /* history is to be set*/
#define HST_TOMOD (HST_TOWRITE | HST_HIST2SET)

/* Flags de type d'acces au fichier donnees */
#define FL_READ 	1
#define FL_WR 		2
#define FL_RDWR 	3
#define FL_STDIO 	4
#define FL_TEMP 	8
#define FL_PIPE 	0x10
#define FL_BD 		0x20
#define FL_MEM 		0x40
#define FL_SWAP 	0x80
#define FL_SUBPROC 	0x100   /* pipe de sous-process */

/* version flags */
#define IV_OLD 1   /* old inrimage version (without magic nb nor float type */
#define IV_INR3 2  /*  inrimage version 3 (idem old + magic number et flottant)*/
#define IV_INR4 3   /* nouvelle version */
#define IV_VLOG 4  /* visilog */
#define IV_MAX 4   /* numero max de version */
#define IV_COMPRESSED 0x100  /* flag rajoute par is_inrimage si compresse */
#define IV_OTHERIM 0x200  /* image non Inrimage, lisible par filtre : is_inrimage */

/*  les bits du flag de verification de codage */
#define VER_COD 1  /* verif codage */
#define VER_DIM 2  /* verif dimensions */
#define VER_XCOD 8 /* verif type etendu (code + bias +scale) */
#define VER_OFF 4  /* verif offset  + maille */
#define VER_EXTEND 0x10
#define VER_MINMASK (VER_COD | VER_DIM)
#define VER_MASK (VER_COD | VER_DIM | VER_OFF | VER_XCOD)
#define VER_XMASK (VER_EXTEND | VER_XCOD | VER_OFF)

/* les indices dans lfmt */
#define	I_DIMX	0
#define I_DIMY	1
#define I_BSIZE	2
#define I_TYPE	3

#define I_NDIMX	4
#define I_NDIMY	5
#define I_NDIMV	6
#define I_NDIMZ	7
#define I_EXP	8
/* macros d'acces a lfmt */
#define	DIMX	lfmt[0]
#define DIMY	lfmt[1]
#define BSIZE	lfmt[2]
#define TYPE	lfmt[3]

#define NDIMX	lfmt[4]
#define NDIMY	lfmt[5]
#define NDIMV	lfmt[6]
#define NDIMZ	lfmt[7]
#define EXP	lfmt[8]
/* EXP = exposant pour images virg. fixe, = type de flottant pour images reelles */
/* valeurs possibles de TYPE */
#define REELLE	1
#define FIXE	0
#define PACKEE	-1

/* define pour offsets */
#define X_OFFSET offsets[0]
#define Y_OFFSET offsets[1]
#define Z_OFFSET offsets[2]

/* maillage */
#define I_RECTA 	0
#define I_HEXAG 	1

/* protections des fichiers image */
#define PMODE	0644	/* rw owner , r group , r others */

/* structure d'informations complementaires sur nf, pour programme utilisateur */
typedef struct nf_info {
	int bits_lig;
	int hors_tout;
	int flt_typ;   /* float type */
	int flt_conv;  /* 1 si conversion necessaire, -1 si impossible, 0 sinon */
	int file_typ;  /* = f_type de image */
	int i_version;  /* version du systeme : inrimage, visislog */
}  NF_info;

/* common unites_ */
struct unites {
	Fort_int lus[16];
	Fort_int lutek;
	Fort_int ires[10];
	Fort_int tekin;
	Fort_int noms[5];
	short ivt[2]; /* vitesse tek */
};

/* common tktrnx_ */
struct tktrnx {
	char *tkbuf;
	Fort_int tksize;
	Fort_int tkoff;
	int tk_psmode;  /* != 0 si PostScript */
	short tk_page;  /* != 0 si page non vide */
	short tk_path;  /* != 0 si trace en cours */
	short tk_text;  /* in text mode */
	short tk_lastpos[2];
};

/* external definitions pour argv et argc */
extern int xargc;
extern char **xargv;

/* structure utilisee par executables a plusieurs noms */
struct multi_cmd {
	char *name;  /* basename of command */
	char *ucmd;  /* short usage message */
	char *udetail;  /* detailed message */
};

/* definitions pour intervalles de pixels */
#define ITVL_B_INF 1   /* il y a une borne inf */
#define ITVL_B_SUP 2   /* il y a une borne sup */
#define ITVL_INF_CLOSED 4  /* borne inf comprise */
#define ITVL_SUP_CLOSED 8  /* borne sup comprise */
#define ITVL_NEGATE 0x10   /* exterieur de l'intervalle */
#define MSK_ITVL (ITVL_B_INF | ITVL_B_SUP | ITVL_INF_CLOSED | ITVL_SUP_CLOSED | ITVL_NEGATE)

/* *************************************** */
#ifndef NO_PROTOS  /* define NO_PROTOS to ignore the definitions */
/* prototypes des fonctions documentees */
#include <stdio.h>
#ifdef __STDC__
#define ARGS(args) args
/* include utile pour quelques struct */
#include <inrimage/dialog.h>
#else
#define ARGS(args) ()
#endif
/* les fonctions definies en Fortran */
extern Fort_int ihxget_ ARGS((Fort_int *icrlf, char *text));
extern Fort_int icpfmg_ ARGS((Fort_int lfmt1[],Fort_int lfmt2[]));
extern Fort_int wrfmg_ ARGS((Fort_int lfmt[],Fort_int *iopt));
extern Fort_int setup_ ARGS((Fort_int *ndim,Fort_int lfmt[],Fort_int *nrow,
			    Fort_int *rwrst,Fort_int *ndima ));
extern Fort_int trtbl_ ARGS((char *a,Fort_int *ndima,Fort_int *ixa,char *b,
			     Fort_int *ndimb,Fort_int *ixb,Fort_int *npoin,
			     Fort_int *nlig,Fort_int *ibs ));
extern double realck_ ARGS((Fort_int *icrlf, char *text,float *s1, float *s2));
extern Fort_int tbvtp1_ ARGS((char *a1,char *a2,Fort_int *i,Fort_int *ndimv,
			      Fort_int *nbv,Fort_int *nbits));
extern Fort_int tbp1tv_ ARGS((char *a1,char *a2,Fort_int *i,Fort_int *ndimv,
			      Fort_int *nbv,Fort_int *nbits));
/* les fonctions a definir "a la main" */
extern int imerror ARGS(( int code, char * format, ...));
extern int exec_ ARGS(( Fort_int * ier, Fort_int * nbfixe, Fort_int *dimfixe, Fort_int * nbvar, Fort_int *pdsvar, int (*proc)(), ...));
extern int imexec_ ARGS(( Fort_int * ier, Fort_int * nbfixe, Fort_int *dimfixe, Fort_int * nbvar, Fort_int *pdsvar, int (*proc)(),... )); 
/* il faut supprimer la definition de imerror, exec, imexec  de la liste 
ci-dessous, pour garder la precedente
*/
/************* la suite est fabriquee automatiquement (voir ../Cprotos) ** */
extern int add_hinfo ARGS(( Inrimage * nf, char * key, int keyl, char * strg, int strl, int truncate ));
extern Fort_int *adress_ ARGS(( Fort_int * var ));
extern int apply_1ct ARGS(( unsigned char * bufi, unsigned char * bufo, int n, unsigned char * coltb ));
extern int apply_ctvect ARGS(( unsigned char * bufi, unsigned char * bufo, int n, unsigned char * tabr, unsigned char * tabg, unsigned char * tabb ));
extern FILE *asciifileopt ARGS(( char * opt, int type ));
extern int assdev0 ARGS(( int k, char * name, int flg ));
extern int asstek_ ();
extern int auto_history ARGS(( Inrimage * nf ));
extern char *inr_basename ARGS(( char * s ));
extern int bcherr_ ();
extern int bclr_ ARGS(( CHAR * a, Fort_int * k ));
extern int bld_hdrl ARGS(( Inrimage * nf, char * p0 ));
extern int bld_hdrl3 ARGS(( Inrimage * nf ));
extern int bld_hdrl4 ARGS(( Inrimage * nf ));
extern int bld_hdrlg ARGS(( Inrimage * nf ));
extern int bld_hdrlv ARGS(( Inrimage * nf ));
extern int bld_imdesc ARGS(( Inrimage * nf ));
extern int bset_ ARGS(( CHAR * a, Fort_int * k ));
extern Fort_int btest_ ARGS(( CHAR * a, Fort_int * k ));
extern int buffer_align ARGS(( char * buf ));
extern int buffer_pgsize ARGS(( Fort_int * lfmt, int nlig ));
extern int buffer_pgsplit ARGS(( int size, int nb ));
extern int buffer_size ARGS(( Fort_int * lfmt, int nlig ));
extern int buffer_split ARGS(( int size, int nb ));
extern int bwc8_to_c24 ARGS(( unsigned char * bufi, unsigned char * bufr, unsigned char * bufg, unsigned char * bufb, int n, unsigned char ** pcol ));
extern int bwc8_to_cvec ARGS(( unsigned char * bufi, unsigned char * bufo, int n, unsigned char ** pcol ));
extern int c24_to_bw ARGS(( unsigned char * bufr, unsigned char * bufg, unsigned char * bufb, unsigned char * bufo, int n, unsigned char ** pcol ));
extern int c24_to_c8 ARGS(( unsigned char * bufr, unsigned char * bufg, unsigned char * bufb, unsigned char * bufo, int n, unsigned char ** pcol ));
extern int c24_to_cvec ARGS(( unsigned char * bufr, unsigned char * bufg, unsigned char * bufb, unsigned char * bufo, int n, unsigned char ** pcol ));
extern int c8_to_bw ARGS(( unsigned char * bufi, unsigned char * bufo, int n, unsigned char ** pcol ));
extern int c_chkgfm ARGS(( Inrimage * nf, NF_fmt * gfmt, int iopt ));
extern int c_cnvfl8 ARGS(( float * buf, int nb, int fltyp ));
extern int c_cnvflt ARGS(( float * buf, int nb, int fltyp ));
extern int c_cnvtbg ARGS(( void * in, void * out, int ndim, Fort_int * icodi, Fort_int * icodo, Fort_int iexpi, Fort_int iexpo ));
extern int c_cnvvis ARGS(( CHAR * in, CHAR * out, int nb_lignes, Fort_int * lfmt, int iexpo, int reste, int fond, int pas ));
extern int c_ecr ARGS(( Inrimage * nf, int nlig, void *a ));
extern int c_ecrflt ARGS(( Inrimage * nf, int nlig, float *a ));
extern int c_ecrpl ARGS(( Inrimage * nf, int iy, int iz, int npl, int nlig, void *a ));
extern int c_exchtb ARGS(( int ibs, int4 * a, int4 * b, int ia, int ib, int ipa, int ipb, int lgr ));
extern int c_getfil ARGS(( Fort_int icrlf, char * text, char * fil ));
extern int c_getgfm ARGS(( Inrimage * nf, NF_fmt * gfmt, int type ));
extern int c_getnom ARGS(( int icrlf, char * text, char * nom, char * nomold, int lgr ));
extern int c_hxdonn ARGS(( char * chain, int i0, int i2, Fort_int * ier ));
extern int c_iask ARGS(( int icrlf, char * text ));
extern int c_icode ARGS(( int val, char * itab, int * lgr ));
extern int c_idonne ARGS(( char * chain, int i0, int i2, Fort_int * ier ));
extern int c_iempty ARGS(( Inrimage * nf ));
extern int c_igetln ARGS(( int icrlf, char * text, char * buf, int lgr ));
extern struct image *c_imouv ARGS(( char * nfic, NF_fmt * gfmt, int iopt ));
extern int c_intch ARGS(( int icrl1, char * text, int icrl2, int n, Fort_int * itab ));
extern int c_intchk ARGS(( int icrlf, char * text, int i1, int i2 ));
extern int c_intget ARGS(( int icrlf, char * text ));
extern int c_iwrcom ARGS(( Inrimage * nf, char * buf ));
extern int c_iwrhis ARGS(( Inrimage * nf, char * string ));
extern int c_lecflt ARGS(( Inrimage * nf, int nlig, float* a ));
extern int c_lect ARGS(( Inrimage * nf, int nlig, void *a ));
extern int c_lectpl ARGS(( Inrimage * nf, int iy, int iz, int npl, int nlig, void *a ));
extern int c_lptget ARGS(( Inrimage * nf ));
extern int c_lptset ARGS(( Inrimage * nf, int n ));
extern int c_lstcmd ARGS(( unsigned char * icmd, int iop ));
extern int c_ltchai ARGS(( char * itab, int nmx, char * brk, int nbrk, char * ibrkch ));
extern int c_modint ARGS(( int icrlf, char * msg, char * format, int * nb ));
extern int c_modreal ARGS(( int icrlf, char * msg, float * nb ));
extern int c_mvbits ARGS(( CHAR * in, CHAR * out, int i_in, int i_out, int nb_bits ));
extern int c_mvbyte ARGS(( CHAR * in, CHAR * out, int nbytes ));
extern int c_mvints ARGS(( int * in, int * out, int nmots ));
extern int c_mvmots ARGS(( Fort_int * in, Fort_int * out, int nmots ));
extern int c_outstr ARGS(( int crlf, char * text ));
extern struct image *c_ouvimf ARGS(( char * nfich, NF_fmt * gfmt, int iagn ));
extern int c_pckbt ARGS(( CHAR * in, CHAR * out, int nb, int bsize ));
extern int c_pecr ARGS(( Inrimage * nf, int nlig, void *a, int iy, int lock ));
extern int c_pecrpl ARGS(( Inrimage * nf, int iy, int iz, int npl, int nlig, void *a, int lock ));
extern int c_plect ARGS(( Inrimage * nf, int nlig, void *a, int iy, int lock ));
extern int c_plectpl ARGS(( Inrimage * nf, int iy, int iz, int npl, int nlig, void *a, int lock ));
extern int c_prtnf ARGS(( Inrimage * nf, int opt, FILE * fd ));
extern int c_realch ARGS(( int icrl1, char * text, int icrl2, int n, float * rtab ));
extern float c_realgt ARGS(( int icrlf, char * text ));
extern int c_trtblb ARGS(( unsigned char * in, int ndimi, int ixi, unsigned char * out, int ndimo, int ixo, int npoin, int nlig, int ibs ));
extern int c_tbvenp ARGS(( char *a, char *b, int npts, int nbits, int ndimv, int iv, int nbv));
extern int c_tbvtp1 ARGS(( char *a, char *b, int iv, int ndimv, int nbv, int nbits));
extern int c_tbpenv ARGS(( char *a, char *b, int npts, int nbits, int ndimv, int iv, int nbv));
extern int c_tbp1tv ARGS(( char *a, char *b, int iv, int ndimv, int nbv, int nbits));
extern int c_unpkbt ARGS(( CHAR * in, CHAR * out, int nb, int bsize ));
extern int c_wrstrg ARGS(( int icrlf, char * text, int fd ));
extern int c_xecr ARGS(( Inrimage * nf, int nlig, CHAR * a, int flg_pad ));
extern int c_xlect ARGS(( Inrimage * nf, int nlig, CHAR * a, int flg_pad ));
extern int c_zcore ARGS(( Fort_int * tab, int n ));
extern int c_zcore_float ARGS(( float * tab, int n ));
extern int cdec_gould ARGS(( int4 * buf, int nb ));
extern int cdec_ksr1 ARGS(( int4 * buf, int nb ));
extern int cgould_dec ARGS(( int4 * buf, int nb ));
extern int cgould_pe ARGS(( int4 * buf, int4 n ));
extern int cgould_sun ARGS(( int4 * tab, int nb ));
extern int chgtek_ ARGS(( int * itb ));
extern int chk_flname ARGS(( char * fname ));
extern int chk_ftyp ARGS(( int fltyp ));
extern int chk_hdrkey ARGS(( char ** p ));
extern int chk_hist ARGS(( char * key, char * buf ));
extern int chk_msbfirst ARGS(( int fltyp ));
extern int chk_version ARGS(( char * nom ));
extern Fort_int chkgfm_ ARGS(( Inrimage ** nf, NF_fmt * gfmt, Fort_int * iopt ));
extern int chklck ARGS(( char * lck, int uid, int * data ));
extern int chkword ARGS(( unsigned char * word, unsigned char * string ));
extern int cksr1_dec ARGS(( int4 * buf, int nb ));
extern int clearopts ();
extern int close_allnf ();
extern int cnv_1b ARGS(( unsigned long * in, unsigned char * out, int ndim, int type, int nbyte ));
extern int cnv_float2 ARGS(( int4 * buf, int4 nb, int typ_in, int typ_out ));
extern int cnv_float2_8 ARGS(( int4 * buf, int4 nb, int typ_in, int typ_out ));
extern int cnvfl8_ ARGS(( float * buf, Fort_int * n, Fort_int * typ ));
extern int cnvflt_ ARGS(( float * buf, Fort_int * n, Fort_int * typ ));
extern int cnvtbg_ ARGS(( CHAR *a, CHAR *b, Fort_int * ndim, Fort_int * icodi, Fort_int * icodo, Fort_int * iexpi, Fort_int * iexpo ));
extern int cnvto_1b ();
extern int cnvvis_ ARGS(( CHAR * in, CHAR * out, Fort_int * nb_lignes, Fort_int * lfmt, Fort_int * iexpo, Fort_int * reste, Fort_int * fond, Fort_int * pas ));
extern int convcd_ ARGS(( CHAR * cmd, short * icmd, Fort_int * nbcom ));
extern int copie ARGS(( CHAR * in, CHAR * out, int nbl, int nbx, int reste ));
extern int cpe_gould ARGS(( int4 * buf, int4 n ));
extern int cpe_sun ARGS(( int4 * tab, int nb ));
extern int cpyfmg_ ARGS(( Inrimage ** nf, Fort_int * lfmt ));
extern int creat_image ARGS(( Inrimage * nf, int mode ));
extern int csun_dec ARGS(( int4 * buf, int nb, int nw ));
extern int csun_gould ARGS(( int4 * tab, int nb ));
extern int cvax_gould ARGS(( int4 *tab, int n ));
extern int cvax_sun ARGS(( u_int4 * tab, u_int4 nb ));
extern int cvec_to_bw ARGS(( unsigned char * bufi, unsigned char * bufo, int n, unsigned char ** pcol ));
extern int cvec_to_c24 ARGS(( unsigned char * bufi, unsigned char * bufr, unsigned char * bufg, unsigned char * bufb, int n, unsigned char ** pcol ));
extern int cvec_to_c8 ARGS(( unsigned char * bufi, unsigned char * bufo, int n, unsigned char ** pcol ));
extern void decode_pixel ARGS(( char * val, int * pix, int nv, int is_float, char * endc, char sep ));
extern int del_hline ARGS(( Inrimage * nf, int num ));
extern int desc_fmt ARGS(( Inrimage * nf ));
extern int detfic_ ARGS(( char * nfic ));
extern int detsfc_ ARGS(( char * nvol, char * nfic, int * nsf ));
extern int ecr_ ARGS(( Inrimage ** nf, Fort_int * nlig, CHAR * a ));
extern int ecrflt_ ARGS(( Inrimage ** nf, Fort_int * nlig, CHAR * a ));
extern int ecrpl_ ARGS(( Inrimage ** nf, Fort_int * iy, Fort_int * iz, Fort_int * npl, Fort_int * nlig, CHAR *a ));
extern int ermesf_ ARGS(( Fort_int * ier ));
extern int ermess_ ARGS(( Fort_int * is1, Fort_int * is2 ));
extern int erreur_ ARGS(( Fort_int * ier ));
extern void errprt ();
extern int exchtb_ ARGS(( Fort_int * ibs, int4 * a, int4 * b, Fort_int * ia, Fort_int * ib, Fort_int * ipa, Fort_int * ipb, Fort_int * lgr ));
extern int fdseek_ ARGS(( Fort_int * fd, long * num ));
extern int fermnf_ ARGS(( Inrimage ** anf ));
extern int fertek_ ();
extern int fileopt ARGS(( char * name, char * opt_name ));
extern int fileoptg ARGS(( char * name, int lg_name, char * opt_name ));
extern int fillbuf ARGS(( char * dst, int len, int with ));
extern int find_cmd ARGS(( int opt, CHAR * cmd, CHAR * ibuf, int nch, CHAR ** idbcmd ));
extern int fl_type ();
extern int flcore_ ARGS(( Fort_int * dst, Fort_int * len, Fort_int * with ));
extern int flltab_ ARGS(( char * a, Fort_int * i1, Fort_int * i2, Fort_int * icar ));
extern int fmt_desc ARGS(( Inrimage * nf ));
extern int fmt_i3desc ARGS(( Inrimage * nf ));
extern int fmt_i4desc ARGS(( Inrimage * nf ));
extern int fmt_vdesc ARGS(( Inrimage * nf ));
extern int fmtset_ ARGS(( Inrimage ** anf, Fort_int * lfmt ));
extern int fpanic_ ();
extern int fpix_interval ARGS(( char * val, float * itvl, int ndimv ));
extern int get_cmde ARGS(( int icrlf, int type, CHAR * cmd, CHAR * brk, int nbrk, CHAR * prompt ));
extern char *get_flname ARGS(( short ftyp ));
extern int get_fltyp ();
extern int get_hdr3blk ();
extern int get_hdr4blk ();
extern int get_hdrVblk ();
extern int get_hist ();
extern char *get_inr_extfile ();
extern char *get_inr_home ();
extern char *get_user_home ();
extern int get_vers_opt ();
extern int get_version ();
extern int getfil_ ARGS(( Fort_int * icrlf, char * text, char * fil ));
extern int getfmg_ ARGS(( Inrimage ** nf, Fort_int dum, Fort_int * lfmt ));
extern int getgfm_ ARGS(( Inrimage ** anf, NF_fmt * gfmt, Fort_int * type ));
extern int getnom_ ARGS(( Fort_int * icrlf, char * text, char * nom, char * nomold, Fort_int * lgr ));
extern int gfmset_ ARGS(( Inrimage ** anf, NF_fmt * gfmt ));
extern int gtnmim_ ARGS(( char * txt, char * nvol, char * nfich, char * isf ));
extern int gtstopts ARGS(( int ign_file, int ign_dim, int ign_cod ));
extern char **hdrl_alloc ARGS(( Inrimage * nf ));
extern int hist_del ARGS(( Inrimage * nf, int num ));
extern int hist_size ARGS(( Inrimage * nf, int * nbl ));
extern int hlpopt_ ARGS(( char * ucmd, char * udetail ));
extern int hsvtorgb8 ARGS(( int n, float * Hbuf, float * Sbuf, float * Vbuf, int inchsv, float Hmax, unsigned char * rbuf, unsigned char * gbuf, unsigned char * bbuf, int incrgb ));
extern int hxdonn_ ARGS(( char * chain, Fort_int * i0, Fort_int * i2, Fort_int * i, Fort_int * ier ));
extern int i3desc_fmt ARGS(( Inrimage * nf ));
extern int i4desc_fmt ARGS(( Inrimage * nf ));
extern int i4read_hdr ARGS(( Inrimage * nf, int firstblk ));
extern int i_Free ARGS(( char ** pptr ));
extern int i_alloc_debug ARGS(( int idb ));
extern int i_alloc_info ARGS(( FILE * f ));
extern char *i_calloc ARGS(( int nelem, int nbelem ));
extern char *i_malloc ARGS(( int size ));
extern char *i_realloc ARGS(( char * ptr, int size ));
extern Fort_int iacces_ ARGS(( char * file ));
extern int iancmd_ ARGS(( CHAR * icmd, CHAR * ibuf, Fort_int * nch, Fort_int * nc, Fort_int * idb ));
extern Fort_int iand_ ARGS(( Fort_int * i, Fort_int * j ));
extern Fort_int iask_ ARGS(( Fort_int * icrlf, char * text ));
extern int icklck_ ARGS(( char * nom, Fort_int * data0 ));
extern int icmp_ct ARGS(( char * tabr, char * tabg, char * tabb, int maxcol ));
extern Fort_int icmpfg_ ARGS(( Inrimage ** nf1, Inrimage ** nf2 ));
extern int icode_ ARGS(( Fort_int * ival, char * itab, Fort_int * lgr ));
extern int icop_ct ARGS(( Inrimage * nfi, Inrimage * nfo ));
extern Fort_int icpgfm_ ARGS(( NF_fmt * gfmt1, NF_fmt * gfmt2 ));
extern int idel_ct ARGS(( Inrimage * nf ));
extern int idelhline ARGS(( Inrimage * nf, char * key, int num ));
extern int idonne_ ARGS(( char * chain, Fort_int * i0, Fort_int * i2, Fort_int * i, Fort_int * ier ));
extern int iempty_ ARGS(( Inrimage ** nf ));
extern Fort_int ieor_ ARGS(( Fort_int * i, Fort_int * j ));
extern int iexst_ ARGS(( int * vol, char * file, int * sf ));
extern Fort_int ifattr_ ARGS(( Fort_int * lu, char ** nom, Fort_int * ityp, Fort_int * itail, Fort_int * ist ));
extern int ifermf_ ARGS(( Fort_int * n ));
extern int ifreehdr ARGS(( Inrimage * nf ));
extern long ifsize_ ARGS(( char * path ));
extern int igethline ARGS(( Inrimage * nf, char * key, int num, char * buf, int size, int * realsize ));
extern Fort_int igetln_ ARGS(( Fort_int * icrlf, char * text, char * buf, Fort_int * lgr ));
extern int igetopt ARGS(( char * opt, char * fopt, void * varopt, char * f1, void * v1, char * f2, void * v2 ));
extern int igetopt0 ARGS(( char * opt ));
extern int igetopt0x ARGS(( char * opt, char * fopt, void * varopt ));
extern int igetopt1 ARGS(( char * opt, char * f1, void * v1 ));
extern int igetopt2 ARGS(( char * opt, char * f1, void * v1, char * f2, void * v2 ));
extern int igetopt2v ARGS(( char * opt, char * f1, void * v1, char * f2, void * v2 ));
extern int ilbyte_ ARGS(( Fort_int * k, CHAR * l, Fort_int * m ));
/** @addtogroup ioimage
 */
extern Inrimage *image_ ARGS(( char * nom, char * mode, char * verif, Fort_int *gfmt ));
#define c_image image_
extern Inrimage *imagex_ ARGS(( char *nom, char * mode, char *verif, NF_fmt *gfmt));
#define c_imagex imagex_
extern int imchek_ ARGS(( char * file ));
#define c_imchek imchek
extern int imouvg_ ARGS(( Fort_int * nvol, char * nfic, Inrimage ** nf, Fort_int * isf, NF_fmt * gfmt, Fort_int * iopt ));
extern int imperr_ ARGS(( Fort_int * ier ));
extern int c_imperr ARGS(( int ier));
extern int infileopt ARGS(( char * name ));
extern int init_hdr ARGS(( Inrimage * nf, int hdrl ));
extern int init_hdrkeys ();
extern int init_nf ARGS(( Inrimage * nf, int mode ));
extern int initopts ARGS(( int argc, char ** argv ));
extern int inr_init ARGS(( int argc, char ** argv, char * progversion, char * ucmd, char * udetail ));
extern int inr_exit ();
extern char *inr_mycalloc ARGS(( int size, int n, char * txt ));
extern int inr_myfree ARGS(( char * pc ));
extern char *inr_mymalloc ARGS(( int n, char * txt ));
extern char *inr_myrealloc ARGS(( void * ptr, int n, char * txt ));
extern int inr_setopts ();
extern int inr_startsubproc ARGS(( CHAR * name, int num ));
extern int inr_tstext ARGS(( CHAR * name ));
extern int intch_ ARGS(( Fort_int * icrl1, char * text, Fort_int * icrl2, Fort_int * n, Fort_int * itab ));
extern Fort_int intchk_ ARGS(( Fort_int * icrlf, char * text, Fort_int * i1, Fort_int * i2 ));
extern Fort_int intget_ ARGS(( Fort_int * icrlf, char * text ));
extern Fort_int ior_ ARGS(( Fort_int * i, Fort_int * j ));
extern int ipix_interval ARGS(( char * val, int * itvl, int ndimv ));
extern int iputhline ARGS(( Inrimage * nf, char * key, char * buf ));
extern Fort_int iquel1_ ARGS(( CHAR * icmd, CHAR * brk, Fort_int * nbrk, CHAR * ih ));
extern Fort_int iquel_ ARGS(( CHAR * icmd, CHAR * brk, Fort_int * nbrk, CHAR * ih ));
extern int ird_ctfile ARGS(( Inrimage * nf, int * i0, int * nb, char * bufr0, char * bufg0, char * bufb0, int maxcol ));
extern int ird_ctrgb ARGS(( Inrimage * nf, int * i0, int * nb, char * bufr, char * bufg, char * bufb, int maxcol ));
extern int irephline ARGS(( Inrimage * nf, char * key, int num, char * buf ));
extern int is_inrimage ARGS(( char * name, int opt ));
extern int isbyte_ ARGS(( Fort_int * k, CHAR * l, Fort_int * m ));
extern short ishft2_ ARGS(( short * i, short * j ));
extern Fort_int ishft_ ARGS(( Fort_int * i, Fort_int * j ));
extern int ismsbfirst ();
extern Fort_int ispipe_ ARGS(( Inrimage ** nf ));
extern int itoggleopt ARGS(( char * opt, char ** table0, int n ));
extern int iusage_ ARGS(( char * cmd, char * detail ));
extern int iverifopt ARGS(( char * opt ));
extern int iwr_ctbw ARGS(( Inrimage * nf, int i0, int nb, char * buf ));
extern int iwr_ctrgb ARGS(( Inrimage * nf, int i0, int nb, char * bufr, char * bufg, char * bufb ));
extern int iwrcom_ ARGS(( Inrimage ** anf, char * buf ));
extern int iwrhis_ ARGS(( Inrimage ** anf, char * string ));
extern int kdopts_ ();
extern int khchk_version ARGS(( int num ));
extern int lchint ARGS(( int i1, int i2, int i3 ));
extern int lecflt_ ARGS(( Inrimage ** nf, Fort_int * nlig, CHAR * a));
extern int lect_ ARGS(( Inrimage ** nf, Fort_int * nlig, CHAR * a ));
extern int lectpl_ ARGS(( Inrimage ** nf, Fort_int * iy, Fort_int * iz, Fort_int * npl, Fort_int * nlig, CHAR *a ));
extern int lgrline ARGS(( char * s ));
extern int lgrword ARGS(( char * string ));
extern Fort_int ligbit_ ARGS(( Fort_int * ifmt, Fort_int * ibs ));
extern Fort_int locflt_ ARGS(( Fort_int * type ));
extern int lptget_ ARGS(( Inrimage ** nf ));
extern int lptset_ ARGS(( Inrimage ** nf, Fort_int * n ));
extern int lstcmd_ ARGS(( unsigned char * icmd, Fort_int * iop ));
extern int ltcara_ ARGS(( Fort_int * icar ));
extern int ltchai_ ARGS(( char * itab, Fort_int * nmx, Fort_int * nchr, char * brk, Fort_int * nbrk, char * ibrkch ));
extern int meserr_ ARGS(( char * mess, Fort_int * is1 ));
extern int mod_hdrl ARGS(( Inrimage * nf ));
extern int movbts_ ARGS(( CHAR * in, CHAR * out, Fort_int * i_in, Fort_int * i_out, Fort_int * nbits ));
extern int move_line ARGS(( char * sce, char * dest, int nmax ));
extern int mvb_debut ARGS(( CHAR * in, CHAR * out, int fb_in, int fb_out, int nb_bits ));
extern int mvb_fin ARGS(( CHAR * in, CHAR * out, int fb_in, int fb_out, int nb_bits ));
extern int mvbyte_ ARGS(( CHAR * in, CHAR * out, Fort_int * i_in, Fort_int * i_out, Fort_int * nbytes ));
extern int mvmots_ ARGS(( Fort_int * in, Fort_int * out, Fort_int * nmots ));
extern int next_key ARGS(( Inrimage * nf, char * key, int n0 ));
extern struct image *nf_alloc ARGS(( char * filename ));
extern Fort_int nivmac_ ARGS(( Fort_int * niv ));
extern Fort_int not_ ARGS(( Fort_int * i ));
extern int open_image ARGS(( Inrimage * nf, int mode ));
extern int opt_modfmt ARGS(( NF_fmt * gfmt, int iopt ));
extern int optfmt_ ARGS(( NF_fmt * gfmt, Fort_int * iopt ));
extern int c_optfmt ARGS(( NF_fmt * gfmt, Fort_int iopt ));
extern int outfileopt ARGS(( char * name ));
extern int outstr_ ARGS(( Fort_int * crlf, char * text ));
extern int ouvdev_ ARGS(( char * nom, Fort_int * n, Fort_int * iflag, Fort_int * nretry ));
extern int ouvns_ ARGS(( Fort_int * nvol, char * nfich, Inrimage ** nf, Fort_int * isf, Fort_int * ifmt, Fort_int * nfmt, Fort_int * iagn, Fort_int * iags, Fort_int * iprot ));
extern int pckbt_ ARGS(( CHAR * in, CHAR * out, Fort_int * nb, Fort_int * bsize ));
extern int print_version ();
extern int prt_cmde1 ARGS(( CHAR * pc, int n ));
extern int prtlck_ ARGS(( Fort_int * data0 ));
extern int prtnf_ ARGS(( Inrimage ** anf, Fort_int * aopt, FILE ** fd ));
extern int put_gfmt ARGS(( Inrimage * nf, NF_fmt * gfmt, int type ));
extern int rcodx_ ARGS(( float * res, char * tab1, Fort_int * lgr, Fort_int * lgd ));
extern int rd_imdesc ARGS(( Inrimage * nf ));
extern int rdfmg_ ARGS(( NF_fmt * gfmt, Fort_int * iopt ));
extern int c_rdfmg ARGS(( NF_fmt * gfmt, Fort_int iopt ));
extern int read_all ARGS(( int fd, char * buf, int len ));
extern int read_pad ARGS(( int fd, CHAR * a, int nlig, int bits_ligne ));
extern int realch_ ARGS(( Fort_int * icrl1, char * text, Fort_int * icrl2, Fort_int * n, float * rtab ));
extern double realgt_ ARGS(( Fort_int * icrlf, char * text ));
extern int repl_hline ARGS(( Inrimage * nf, int num, int offset, char * strg ));
extern int rgb8tohsv ARGS(( int n, float * Hbuf, float * Sbuf, float * Vbuf, int inchsv, float Hmax, unsigned char * rbuf, unsigned char * gbuf, unsigned char * bbuf, int incrgb ));
extern int rmnf_ ARGS(( Inrimage ** nf ));
extern int set_c8_1ct ARGS(( unsigned char * col, int numc ));
extern int set_c8_ct ARGS(( unsigned char * pcr, unsigned char * pcg, unsigned char * pcb ));
extern int set_hdr_min ARGS(( int nblk ));
extern int set_hdrl ARGS(( Inrimage * nf ));
extern int sorry ();
extern int strcpp ARGS(( char * s ));
extern int swapint4 ARGS(( u_int4 * buf, int nb ));
extern int swapint8 ARGS(( u_int4 * buf, int nb ));
extern int swapshort ARGS(( unsigned short * buf, int nb ));
extern int tek_select ARGS(( char * pc ));
extern int testopt ();
extern int trtblb_ ARGS(( char * a, Fort_int * ndima, Fort_int * ixa, char * b, Fort_int * ndimb, Fort_int * ixb, Fort_int * npoin, Fort_int * nlig, Fort_int * ibs ));
extern int tst_hdrkey ARGS(( char * strg ));
extern int tstnbopts ();
extern int tstoptm ();
extern int tstopts ();
extern int unpkbt_ ARGS(( CHAR * in, CHAR * out, Fort_int * nb, Fort_int * bsize ));
extern int vdesc_fmt ARGS(( Inrimage * nf ));
extern int ver_gfmt ARGS(( NF_fmt * gfmt, int iopt ));
extern char *version_name ARGS(( int version ));
extern int wr_imdesc ARGS(( Inrimage * nf ));
extern int wrfmgg_ ARGS(( Fort_int * lfmt, Fort_int * iopt, Fort_int * lu ));
extern int c_wrfmgg ARGS(( Fort_int * lfmt, Fort_int iopt, Fort_int lu ));
extern int c_wrfmg ARGS(( Fort_int * lfmt, Fort_int iopt));
extern int write_pad ARGS(( int fd, CHAR * a, int nlig, int bits_ligne ));
extern int wrstrg_ ARGS(( Fort_int * icrlf, char * text, Fort_int * lu ));
extern int wrtbi_ ARGS(( Fort_int * icrlf, char * text, Fort_int * icrl1, Fort_int * n, Fort_int * itab, Fort_int * iform, Fort_int * lu ));
extern int xfileopt ARGS(( char * name, char * opt_name, int required ));
extern int xfileoptg ARGS(( char * name, int lg_name, char * opt_name, int required ));
extern int zcore_ ARGS(( Fort_int * tab, Fort_int * n ));
extern int zcoref_ ARGS(( float * tab, Fort_int * n ));
/* fin de la partie fabriquee automatiquement ********* */
#endif /* NO_PROTOS */
#endif /* INR_image_included */

