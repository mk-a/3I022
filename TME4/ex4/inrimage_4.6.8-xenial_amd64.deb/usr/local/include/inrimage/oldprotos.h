/*
-* == Les fonctions d'INRIMAGE
*/
extern void      bcherr_() ;
extern void      bset_ARGS((char *a, int *k)) ;
extern void      bclr_(char *a, int *k) ;
extern int       btest_(char *a, int *k) ;
extern int       chkgfm_(Inrimage **nf,  NF_fmt *gfmt, int *iopt) ;
extern int       c_chkgfm(Inrimage *nf,  NF_fmt *gfmt, int iopt) ;
extern int       chkword(unsigned char *word, unsigned char *string) ;
extern int       lgrword(char *string) ;
extern int       lgrline(char *s) ;

extern int       move_line(char *sce, char *dest, int nmax) ;
extern int       cnvflt_(long *buf, long *n, int *typ) ;
extern int       c_cnvflt(long *buf, int nb, int fltyp) ;
extern int       cnv_float2(long *buf, long nb, int typ_in, int typ_out) ;
extern int       cpe_gould(long *buf, long n) ;
extern int       cgould_pe(long *buf, long n) ;
extern int       csun_gould(long *tab, int nb) ;
extern int       cvax_sun(long *tab, long nb) ;
extern int       cgould_sun(long *tab, int nb) ;
extern int       cpe_sun(long *tab, int nb) ;
extern int       cdec_sun(long *buf, int nb) ;
extern int       cvax_gould(long *buf, int nb) ;
extern int       csun_dec(long *buf, int nb) ;
extern int       cdec_gould(long *buf, int nb) ;
extern int       cgould_dec(long *buf, int nb) ;
extern void      swaplong(unsigned long *buf, int nb) ;
extern void      swapshort(unsigned short *buf, int nb) ;
extern int       creat_image(Inrimage *nf, int mode) ;
extern int       i3desc_test(Descripteur *, int) ;
extern int       init_hdr(Inrimage *nf, int hdrl) ;
extern void      rdfmg_(NF_fmt *gfmt, int *iopt) ;
extern void      ecr_(Inrimage **nf, int *nlig, char *a) ;
extern void      c_ecr(Inrimage *nf, int nlig, char *a) ;
extern void      c_xecr(Inrimage *nf, int nlig, char *a, int flg_pad) ;
extern int       write_pad(int fd, char *a, int nlig, int bits_ligne) ;
extern void      ermesf_(int *ier) ;
extern void      ermess_(int *is1, int *is2) ;
extern void      errprt() ;
extern int       fermnf_(Inrimage **anf) ;
extern Inrimage  *nf_alloc(char *filename) ;
extern void      close_allnf() ;

extern int       desc_fmt(Inrimage *nf) ;
extern int       fmt_desc(Inrimage *nf) ;
extern char    **hdrl_alloc(Inrimage *nf) ;
extern int       bld_hdrlg(Inrimage *nf) ;
extern int       bld_hdrl(Inrimage *nf, char *p0) ;
extern void      fillbuf(char *dst, int len, int with) ;
extern void      flcore_(int *dst, int *len, int *with) ;
extern int       locflt_(int *type)  ;
extern int       fl_type() ;
extern int       get_fltyp() ;
extern int       chk_ftyp(int fltyp) ;

extern char     *get_flname(short ftyp) ;
extern int       chk_flname(char *fname) ;
extern int       ismsbfirst() ;
extern int       chk_msbfirst(int fltyp) ;
extern void      getgfm_(Inrimage **anf, NF_fmt *gfmt, int *type) ;
extern void      c_getgfm(Inrimage *nf, NF_fmt *gfmt, int type) ;
extern void      put_gfmt(Inrimage *nf, NF_fmt *gfmt, int type) ;
extern int       next_key(Inrimage *nf, char *key, int n0) ;
extern int       del_hline(Inrimage *nf, int num) ;
extern int       repl_hline(Inrimage *nf, int num, 
                            int offset, char *strg);
extern int       add_hinfo(Inrimage *nf, char *key, int keyl,
                           char *strg, int strl, int truncate) ;
extern int       chk_hist(char *key, char *buf) ;
extern int       idelhline(Inrimage *nf, char *key, int num) ;
extern int       ifreehdr(Inrimage *nf) ;
extern int       igethline(Inrimage *nf, char *key, int num,
                           char *buf, int size, int *realsize) ;
extern void      iwrcom_(Inrimage **anf, char *buf) ;
extern int       c_iwrcom(Inrimage *nf, char *buf) ;
extern int       iputhline(Inrimage *nf, char *key, char *buf) ;
extern int       irephline(Inrimage *nf, char *key, int num, char *buf) ;
extern void      init_hdrkeys() ;
extern int       tst_hdrkey(char *strg) ;
extern int       chk_hdrkey(char **p) ;
extern int       auto_history(Inrimage *nf) ;
extern int       iwrhis_(Inrimage **anf, char *string) ;
extern int       c_iwrhis(Inrimage *nf, char *string) ;
extern int       hist_del(Inrimage *nf, int num) ;
extern void      hxdonn_(char *chain, int *i0, int *i2, int *i, int *ier);
extern int       c_hxdonn(char *chain, int i0, int i2, int *ier) ;
extern void      idonne_(char *chain, int *i0, int *i2, int *i, int *ier);
extern int       c_idonne(char *chain, int i0, int i2, int *ier) ;
extern long      ifsize_(char *path) ;
extern int       igetopt(char *opt, char *fopt, char *varopt,
                         char *f1, char *v1, char *f2, char *v2) ;
extern Inrimage *image_(char *nom, char *mode, char *verif, 
                        NF_fmt *gfmt);
//extern void      imerror(int code, char *format, ...) ;
extern void imerror(int code = 0,char *format = NULL, int p1 = 0, 
		int p2 = 0, int p3 = 0, int p4 = 0, int p5 = 0, 
		int p6 = 0, int p7 = 0, int p8 = 0) ;
extern void imouvg_(char *nfic, Inrimage **nf,
             NF_fmt *gfmt, int *iopt) ;
extern Inrimage *c_imouv(char *nfic, NF_fmt *gfmt, int iopt) ;
extern void      initopts(int argc, char **argv) ;
extern int       i3desc_fmt(Inrimage *nf) ;
extern int       bld_hdrl3(Inrimage *nf) ;
extern int       fmt_i3desc(Inrimage *nf) ;
extern int       i4desc_fmt(Inrimage *nf) ;
extern int       i4read_hdr(Inrimage *nf, int firstblk) ;
extern int       bld_hdrl4(Inrimage *nf) ;
extern int       fmt_i4desc(Inrimage *nf) ; 
extern int       set_hdrl(Inrimage *nf) ;
extern int       mod_hdrl(Inrimage *nf) ;
extern int       hdrl_add1(struct hdr_keys *pk) ;

extern int       get_version() ;
extern int       chk_version(char *nom) ;
extern int       get_vers_opt() ;
extern char     *version_name(int version) ;
extern int       get_hdrVblk() ;
extern int       get_hdr3blk() ;
extern int       get_hdr4blk() ;
extern int       get_hist() ;
extern void      lect_(Inrimage *nf, int *nlig, char *a) ;
extern void      c_lect(Inrimage *nf, int nlig, char *a) ;
extern void      c_xlect(Inrimage *nf, int nlig, char *a, int flg_pad);
extern int       read_pad(int fd, char *a, int nlig, int bits_ligne) ;
extern void      mvbits_(char *in, char *out, int *i_in, 
                         int *i_out, int *nbits) ;

extern void      c_mvbits(char *in, char *out, int i_in,
                          int i_out, int nb_bits) ;
extern void      mvb_fin(char *in, char *out, int fb_in,
                         int fb_out, int nb_bits) ;
extern void      mvb_debut(char *in, char *out,
                         int fb_in,int fb_out, int nb_bits) ;
extern void      mvbyte_(char *in, char *out, int *i_in,
                         int *i_out, int *nbytes) ;
extern void      c_mvbyte(char *in, char *out, int nbytes)  ;
extern void      mvmots_(int *in, int *out, int *nmots) ;
extern void      c_mvmots(int *in, int *out, int nmots) ;
extern int       nivmac_(int *niv) ;
extern int       open_image(Inrimage *nf, int mode) ;
extern int       init_nf(Inrimage *nf, int mode) ;
extern int       rd_imdesc(Inrimage *nf) ;
extern int       bld_imdesc(Inrimage *nf) ;
extern int       wr_imdesc(Inrimage *nf) ;
extern void      swapdesc(Descripteur *pi) ;

extern void      swapvdesc(struct vlg_desc *pv) ;
extern int       read_all(int fd, char *buf, int len) ;
extern int       optfmt_(NF_fmt *gfmt, int *iopt) ;
extern int       opt_modfmt(NF_fmt *gfmt, int iopt) ;
extern void      ver_gfmt(NF_fmt *gfmt, int iopt) ;
extern void ouvns_(int *nvol, char *nfich, Inrimage *nf,
            int *isf, int *ifmt, int *nfmt, int *iagn,
            int *iags, int *iprot);

extern  Inrimage *c_ouvimf(char *nfich, NF_fmt *gfmt, int iagn) ;
extern int       vdesc_fmt(Inrimage *nf) ;
extern int       bld_hdrlv(Inrimage *nf) ;
extern int       fmt_vdesc(Inrimage *nf) ;

