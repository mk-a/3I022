#include "image.h"

/* ****************  visilog descripteur */
struct vlg_desc {
        int4 i_magic;   /* magic number */
/* Taille physique de l'enveloppe */
        int4 i_dimx;    /* nb de pixels/ligne */
        int4 i_dimy;    /* nb de lignes par plan */
        int4 i_dimz;    /* nb de plans */
        int4 i_res0;    /* nb d'elements par pixel */
        int4 i_res00;   /* flag de type de rangement des donnees */
        int4 i_maille;  /* type de maillage (rectang. ou hexag. ) */
        int4 i_res1;    /* reserve */
/* Codage arithmetique sur fichier */
        int4 i_code;    /* type de codage (voir image.gcode) */
        int4 i_bstoc;   /* nb de bits de stockage de l'element */
        int4 i_res2;    /* reserve */
        int4 i_orix;    /* Coordonnee en x de l'origine */
        int4 i_oriy;    /* Coordonnee en y de l'origine */
        int4 i_oriz;    /* Coordonnee en z de l'origine */
        int4 i_res3;    /* reserve */
/* Parametres de decodage de l'entete */
        int4 hdr_sys;   /* taille totale en octets du descripteur principal */
        int4 hdr_usr;   /* reserve */
        int4 i_res4;    /* reserve */
        int4 hdr_data;  /* taille en octets de l'en-tete du fichier data */
        } ;
/* float type de visilog */
#define vlg_float i_res2
#define VDESC sizeof(struct vlg_desc)
/* Les formats standards, dans l'ordre:
        flottant
        entier 32 bits signe
        entier 16 bits signe
        entier 8 bits signe
        entier 8 bits non signe
        binaire non packe
        binaire packe */
#define I_FLOAT 0
#define I_LONG 0x01
#define I_SHORT 0x02
#define I_CHR 0x04
#define I_CHRU 0x14
#define I_LABEL 0x42
#define I_BIN 0x22
#define I_BINP 0x20
/* les formats exotiques, packes, non packes */
#define I_PACKED 0x80


/* formats Inrimage */
/* ATTENTION: Il est important que DESC == FILE_HAEDER_LEN */
/* longueur du descripteur */
/*#define DESC	sizeof(struct descripteur) */
#define DESC	256

/* structure descripteur d'image versions <= 3*/
/* NOTE : les int et les short sont ecrits avec MSB first
   mais les floats restent dans le format du cpu qui ecrit */

struct descripteur {
	short dimx;	/* dimension totale en x (=ndimx*ndimv) */
	short ndimy;	/* dimension en y */
	char bsize;	/* nb d'octets ou de bit par points */
	unsigned char flag;	/* octet de flag */
	short ndimz;	/* dimension en z */
	short ndimv;	/* dimension du vecteur (image vectorielle) */
	short ndimx;	/* nb de vecteurs par ligne */
	float4 maximum;	/* valeur du maximum */
	float4 minimum;	/* valeur du minimum */
	float4 moyenne;	/* valeur de la moyenne */
	short exposant;	/* valeur de l'exposant */
	short float_typ;	/* type de flottant, en fait type de cpu */
	int im_magic;   /* magic nb */
	int desc_ext;   /* taille d'extension du header : n*256, >= 0 */
	int x_off;	/* x offset */
	int y_off;	/* y offset */
	int z_off;	/* z offset */
	int maille;	/* 0 = rect, 1= hexa */
	float4 bias;   /* constante a rajouter a chaque pixel (virg. fixe) */
	float4 scale;  /* coeff multiplicatif (virg. fixe) quand il n'est pas 2**n
		       0 = a ignorer */
	char res[68];	/* reserve */
	char comment[128]; /* commentaire */
	} ;
#define IM3_MAGIC 0x49006e00
#define IM3_SWMAGIC 0x006e0049
#define V_MAGIC 0x00006931  /* visilog */
#define V_SWMAGIC 0x31690000  /* visilog */

/* bits de l'octet de flag du descripteur
   MMM indique que maximum, minimum et moyenne sont ecrites dans le descripteur
   COMMENT indique l'existence d'un commentaire dans le descripteur */

#define FLOAT	0x80
/* obsolete !!
#define	MMM	0x40
#define COMMENT	0x20
*/
#define BITS	0x10	
#define PACKED	0x04

/* inrimage version 4 */
#define FILE_HEADER_LEN DESC
/* le header commence et se termine par une chaine magique
le dernier caractere de la chaine de fin doit etre sur le dernier octet d'un bloc */
#define MAGIC_HEADER "#INRIMAGE-4#{"
#define MAGIC_ENDL "##}"
#define MAGIC_END "\n##}\n"
#define END_SIZE (sizeof(MAGIC_END))

/* les mots-cles du header et leur reference */
#define S_NDIMX "XDIM="	/* largeur image */
#define IS_NDIMX 0
#define S_NDIMY "YDIM="	/* hauteur image */
#define IS_NDIMY 1
#define S_NDIMZ "ZDIM="  /* nombre de plans */
#define IS_NDIMZ 2
#define S_NDIMV "VDIM="  /* nb de valeurs en chaque point */
#define IS_NDIMV 3
#define S_TYPE "TYPE="   /* type : signed|unsigned float|fixed|packed */
#define IS_TYPE 4
#define S_BSIZE "PIXSIZE="   /* taillepixel, par ex  8 bits */
#define IS_BSIZE 5
#define S_SCALE "SCALE="    /* exposant pour virgule fixe (fixed), par ex 2**0 */
#define IS_SCALE 6
#define S_CPU "CPU="	    /* cpu type (dec, sun) pour ordre des bits et type float */
#define IS_CPU 7
#define S_BIAS "BIAS="
#define IS_BIAS 8
#define S_XOFF "X0="
#define IS_XOFF 9
#define S_YOFF "Y0="
#define IS_YOFF 10
#define S_ZOFF "Z0="
#define IS_ZOFF 11
#define S_MAILLE "MAILLE="
#define IS_MAILLE 12
#define S_HEADER MAGIC_HEADER
#define IS_HEADER 13
#define S_END MAGIC_ENDL
#define IS_END 14
#define S_HISTORY "#*[H]*"
#define IS_HISTORY 15
#define HDR_NB_KEYS 16
#define HDR_NB_MIN 13
/* la table des mots-cles */
struct hdr_keys {
	char *key;   /* la chaine de caracteres definissant la cle */
	short key_length;  /* la longueur de la cle */
	short key_type;   /* type de data : decimal, string,  etc */
	long key_val;    /* pour stocker la valeur provisoire (nb ou adresse) */
};
#define K_DECIMAL 0
#define K_HEXA 1
#define K_STRING 2
#define S_REELLE "float"
#define S_FIX "fixed"
#define S_PACK "packed"
#define S_BITS "bits"
#define S_SIGN "signed"
#define S_UNSIGN "unsigned"
#define S_RECTA "rectangle"
#define S_HEXA "hexagone"
/*********les modes d'acces aux fichiers **************/
#define IM_RONLY 0
#define IM_WONLY 1
#define IM_RW 2   /* read/write */
#define IM_CRW 6  /* create + RW, uniquement dans 1 cas particulier d'appel de open_image */
