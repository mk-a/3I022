/**
 * @page contlib7intro Documentation (partielle) de la librairie de contours
 *
 * Cette librairie permet de manipuler les fichiers de contours. Les
 * fichier de contours peuvent �tre cr��s de toute pi�ce par l'utilisateur
 * ou bien obtenus � partir des images gr�ce � la commande
 * <a href="../anac.1i.html">anac</a>. Cette derni�re
 * commande repose d'ailleurs enti�rement sur la librairie de contours
 * (contlib7).
 *
 * - Point de d�part de la documentation de la librairie: \ref contlib7.
 * - Exemples d'utilisation de la librairie contlib7.
 *     - Lire ou �crire des fichiers de contour dans les programmes de segmentation.
 * - Exemple d'utilisation des commandes de contours: 
 *     - Cr�ation de masques: voir <a href="../imag_ex.html">exemples avec icompose</a>.
 *     - Visualiser des fichiers de contours.
 */


/*
	structure des fichiers de contours
	(organis�s en blocs de 256 octets)
  structure bloc 0 (indices de mots de 4 octets)
    0=numero contour max, 1=nb effectif de contours, 2=nb de bloc. indx
    3=nb total bloc. index+data, 4=adresse 1er bloc. index
    5=adresse dernier bloc ind., 6=ptr de la 1ere donnee (2*256+2)
    7=ptr du prochain mot libre pour les donnees
    8= magic number (0x00ab) pour nouveau type (longueur et iext en long)
    9=surface totale d'objet (somme algebriques des 1er param. des con
    10=surf. totale des cont. "exterieurs" (somme des val. abs. des
       1ers param. des contours)
    11=nb max de parametres pour un contour donne
    32 a 63 : commentaire termine par 1 short nul.

 structure bloc index : num�ro bloc index precedent, num bloc suivant
    62 ptrs vers datas du contour (ptr num�ro n pour contour n) :
       valeur 256*k+l ou k=num bloc et l=num�ro de mot dans bloc

 structure bloc data : 1 num�ro bloc suivant, 63 mots de data.
   les contours sont ranges consecutivement :
     1/2 mot=lgr effective, 1/2 mot num. enveloppe
      1/2 mot nb de param, 1/2 mot indicateur de chainage (0 si datas
       consecutives, +n si n mots consecutifs pas tous occupes, -n
       si n-1 mots consecutifs suivis d'un ptr vers la suite  dans ce
        cas la suite commence par un mot indicateur de chainage)
    k mots parametres
     mots de donnees (1short x, 1 short y, valeurs >= 1))

NB : les "ptr" sont des indices de mots de 32bits compt�s � partir de 1
  1 mot = 32 bits, 1/2 mot = un short
*/

/* definitions relatives a la taille des blocs */

#define MAXCT 6
#define NBYTE 256
#define NBINT4 64
#define CT_MAGIC 0x000000ab
#define CT_MAGIC_SWAP 0xab000000

struct ct_indx {
	int4 i_prev;	/* adr. du bloc precedent */
	int4 i_next;	/* adr. bloc suivant */
	int4 i_pt[NBINT4-2];	/* ptrs vers data des contours */
};

union hdrdata {
	int4 d_l;
	struct {
		short d_lgr;	/* lgr contour en nb de mots 32bits */
		short d_env;	/* num. enveloppe */
	} d1;
	struct {
		short d_nbpar;	/* nb de parametres associes */
		short d_store;	/* indicateur de stockage des donnees :
			0 si d_lgr donnees a la suite,
			+N si d_lgr donnees sur N mots (N>= d_lgr)
			-N si le 1er mot apres param est un pointeur vers
				nouvelle zone de donnees de taille N. */
	} d2;
};

struct hdrdn {
	int4 dn_lgr;
	int4 dn_env;
	int4 dn_nbpar;
	int4 dn_store;
};

struct ct_s0 {
	int4 ct_nmax;	/* num contour max */
	int4 ct_nb;	/* nb effectif de contours */
	int4 ct_nbsi;	/* nb blocs index */
	int4 ct_nbs;	/* nb total blocs index+ data */
	int4 ct_si1;	/* adr 1er bloc. index */
	int4 ct_sin;	/* adr dernier bloc. index */
	int4 ct_dat1;	/* ptr vers 1e donnee : 2*NBYTE+2 */
	int4 ct_fdat;	/* ptr vers 1er mot de donnees libre */
	int4 ct_magic;
	int4 ct_stot;	/* surface totale */
	int4 ct_stote;	/* surf totale des cont. "exterieurs" */
	int4 ct_npmax;	/* nb max de param. par contour */
};
struct ct_b0 {
	struct ct_s0 b0_s0;
	int4 s_fill[20];
	char s_com[128];	/* commentaire termine par 0 */
};

/**
 * @brief Descripteur de fichier de contours
 */
struct fc_cont {	/* structure associee a 1 fichier de contour ouvert  */
	int4 fc_fd;	/**< descripteur de fichier syst�me associ� */
	int4 fc_numf;	/**< num�ro d'ordre du fichier ouvert (0-MAXCT-1) */
	int4 n_ind;	/**< num�ro d'ordre du bloc index courant */
	int4 s_ind;	/**< adresse bloc index courant */
	int4 s_dat;	/**< adresse bloc datas courant */
	int4 *pt_datn;	/**< adresse dans bloc d'index du contour courant */
	int4 i_dat;	/**< indice courant dans bloc data */
	int4 ct_pos;	/**< indice du mot courant dans l'ensemble des datas
			du contour courant */
	int4 fc_num;	/**< num�ro contour courant */
	int4 fc_numd;	/**< num�ro contour courant pour datas */
	int4 fc_numx;	/**< num�ro contour correspondant a la fin de fichier */
	int4 ct_lgr;	/**< longueur contour courant (si fc_numd == fc_num) */
	char ct_loc;	/**< indication de position : 
			   - 0=ind�t. 
			   - 1=d�but, 
			   - 2=zone par (ptr vers nb param ) 
			   - 3= zone data */
	char fc_flag;	/**< 0= cont.  vide, 1=param seuls, 2=complet */
	char fc_typ;	/**< type 0= old, 1= new (que des int4) */
	char fc_swap_needed;   /**< 1 si ordre des octets fichier et machine diff�rents */
	char fc_posp;	/**< indice de mot du nombre de param�tres */
	char fc_posp2;	/**< indice de mot du premier param�tre */
	char fc_res2[2];
	int4 fc_nbwr;	/**< nombre de blocs du fichier effectivement �crits */
	char flg_i;	/**< bloc. index modifi� */
	char flg_d;	/**< bloc data modifi� */
	char flg_s0;	/**< bloc 0 modifi� */
	char fc_access;	/**< type d'acc�s : R, W, RW, ou Modify 
			Modify = R+W+ possibilit� de modifier le contour */
        char fc_name[80]; /**< nom du fichier associ� */
	struct ct_s0 fc_s0;
	struct ct_indx fc_indx;	/**< bloc index courant */
	int4 fc_dat[NBINT4];	/**< bloc data */
};

#define CT_R 1
#define CT_W 2
#define CT_MOD 4

#define c_nmax fc_s0.ct_nmax
#define c_nb fc_s0.ct_nb
#define c_nbsi fc_s0.ct_nbsi
#define c_nbs fc_s0.ct_nbs
#define c_si1 fc_s0.ct_si1
#define c_sin fc_s0.ct_sin
#define c_dat1 fc_s0.ct_dat1
#define c_fdat fc_s0.ct_fdat
#define c_magic fc_s0.ct_magic
#define c_stot fc_s0.ct_stot
#define c_stote fc_s0.ct_stote
#define c_npmax fc_s0.ct_npmax

struct ct_select {
	int cnt_min, cnt_max;  /* num. min et max >= 1 */
	char *cnt_marks;  /* ptr NULL ou 1 octet/ contour (1 si actif) */
};

#define swap2(x,y) { x = y; y = ((x >> 8) & 0xff) | (x << 8); }
#define swap4(x,y) { x = y;\
y = (x << 24) | ((x & 0xff00) << 8) | ((x >> 8) & 0xff00) | ((x >> 24) & 0xff);}


/** 
 * @defgroup contlib7 contlib7
 * @brief Traitement des fichiers de contours Inrimage 
 * 
 * Cette page est un embryon de documentation de la librairie contlib7
 * d'Inrimage qui permet de manipuler des fichiers de contours.
 */

/** @addtogroup contlib7
 * @{ */

struct fc_cont *c_iouvct(char *nom, int age, char *acces);
void            c_fermct(struct fc_cont *nfc);

void            c_wctcom( struct fc_cont *nfc, char *icom);
int             c_irctcm( struct fc_cont *nfc, char *icom);

int             c_irctdm( struct fc_cont *nfc, int4 *ixy0, int4 *idimxy);
void            c_wctdim( struct fc_cont *nfc, int4 *ixy0, int4 *idimxy);

int             c_irctgp( struct fc_cont *nfc, Fort_int *numax,
			  Fort_int *nbct, Fort_int *npmax,
			  Fort_int *nblocs, Fort_int *iftyp);

int             c_irctpa( struct fc_cont *nfc, int num, Fort_int *isens,
			  Fort_int *iext, Fort_int *lgr, int4* par,
			  int npmax, Fort_int *np);
void            c_wrctpa( struct fc_cont *nfc, int n, int4* par, int np);

int             c_ircttb( struct fc_cont *nfc, int n, int4 *icont, int lgmax);
void            c_wrcttb( struct fc_cont *nfc, int n, int4 *icont, int lgr);

void            c_wrctev( struct fc_cont *nfc, int n, int iext);

void            c_wrctls( struct fc_cont *nfc, int n, int4 *list, int i0, int lgbl, int iop);
void            c_ctdel( struct fc_cont *nfc, int n);

/** @} */
