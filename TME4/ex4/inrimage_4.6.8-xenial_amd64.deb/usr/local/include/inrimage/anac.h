/* les indice et num de contours commencent a 1! */
/* les blocs de contours sont alloues au debut du tas, et les descripteurs a partir de la fin 
*/

struct anac_info {
  int x0, y0, dx, dy;   /* la fenetre */
  int nblig;   /* nb lignes dans buffer image */
  int vmin, vmax;  /* seuils */
  short flg_res;	 /* +1 file, +2 tek */
  short flg_1bit;  /* 1 si image 1bit */
  int iconn;	/* connexite (1=forte)*/
  int ix0_desc;   /* indice char (>=0) limite des descr dans le tas */
  int ix_cont_desc;  /*  indice char (>=0) dans le tas du plus bas descr utilise */
  int ix_chn;     /* indice char (>=0) dans le tas du prochain bloc a prendre */
  int max_iseg;   /* nb max de struct iseg dans anac_iseg (pair) */
  int ipvid;  /* indice+1 1e struct chn de la liste vide 0= aucon  */
  int idesc_min ;  /* val min de ix_cont_desc : pour calculer max cont */
  int ix_chn_max;   /* nb max alloue aux blocs */
  int tot_blocs;   /* nb total blocs chn crees */
  int num_max; /* num max de contour */
  int lg_bmap;  /* taill bitmap en nb char */
  char *bitmap;	/* bit map des num de contours */
  int ndimv;
  int *pix_itvl;  /* intervalle de pixel pour les objets */
  struct nf_ct *anac_ct_out; /* fichier de contour */
};
extern struct anac_info anac_info;  /* defined in ancont.c */


#define NBPTS_BLOC 2  /* nb pts contour par bloc */
struct iseg {  /* pour chaque pt de transition fond/objet de 2 lignes image */
	short x;   /* abscisse >= 1 */
	short idesc;  /* indice+1 du descripteur de contour correspondant */
};
struct cont_desc {  /* descripteur de contour */
	short num;  /* num du contour (<0 pour contour de trou) */
	short numext;  /* num (sans signe) de l'enveloppe */
	short p_bloc, d_bloc;  /* indices (>= 1) 1e et dernier bloc */
	int surf;  /* surface contour avec signe */
};
/* Notes : d_bloc  = 0 quand le coont est ferme
   p_bloc = 0 et d_bloc = lgr quand liste des pts enlevee mais descripteur encore present
*/

struct chn {  /* stockage des pts de contours (blocs de 2 pts) */
	short ip0;  /* indice (>= 1) du prochain  pt dans le bloc (1e et dernier bloc du contour) */
	short inext;  /* indice bloc suivant (dernier bloc -> nb pts) */
	unsigned short pts[2*NBPTS_BLOC];
};
/* Note
on ecrit 1pt en tete de liste et 1 pts en fin
le bloc de tete est rempli a partir de la fin (de NBPTS_BLOC a 1) et
le dernier a partir du debut (de 1 a NBPTS_BLOC)
*/
extern unsigned char *anac_heap;   /* la base du tas */
extern unsigned char *anac_imbuf;   /* le tableau image */
extern struct iseg *anac_iseg;
extern struct cont_desc *anac_desc;  /* le sommet de la liste de descripteurs */
extern struct chn *anac_chn;  /* la zone des blocs de contours */


/* function prototypes */

void c_anaseg( int lseg1, int lseg2, int ilig, int connect);
void c_finchn( struct cont_desc* pdesc, int lseg);
void c_sorchn( struct cont_desc* pdesc, int lseg);
void c_comprs( int idesc, struct iseg* pseg, int lseg);
void c_newchn( int *ipdesc, int iext, int isig);
void c_libchn( void);
int  c_gtbloc( void);
void c_adtchn( struct iseg *pseg, int iy);
void c_finchn( struct cont_desc *pdesc, int lseg);
void c_wrtchn( struct cont_desc *pdesc);
void c_unichn( struct iseg *pseg, int lseg, int iseg1, int iseg2, int iy);
void c_rlschn( int ichn);
void c_comprs( int idesc, struct iseg *pseg, int lseg);
void c_chrseg( unsigned char* buf, int ii0, struct iseg *pseg, int* plseg, int nmax);
void c_dancon( struct image *nf, Fort_int *lfmt, int *dimxy, int * xy0, int *seuils,
	       int *ivis, int *iconn, int lg_bmap);
int  c_ancont( struct iseg *iseg, Fort_int *ifdm, unsigned char *ichn,
	       Fort_int *idim, struct image *nf, Fort_int *lfmt);
void c_ecchtk( struct chn* chn, int j, int isens, int closed, int nbpt, int dmax);
void set_bitmap( int n, int val);
int  tst_bitmap( void);

/* defined in inrgraph */
void c_t4trac( int mode, int itype); 
void c_t4vabs( int ix, int iy, int itrac);
