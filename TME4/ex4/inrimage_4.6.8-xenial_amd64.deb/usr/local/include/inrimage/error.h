#include <setjmp.h>
struct error   {
int (*retadr)(); /* adresse de retour (0=exit, -1=par exec=>utiliser longjmp) */
int code1;	/* code principal */
int aderr;	/* errno ou code err niv. 1 */
int code2;	/* code compl. pour err niv. 1 */
jmp_buf retenv;	/* pour retour dans exec par longjmp */
int silent;     /* set to 1 if we don't want automatic error messages */
};
#define x_errno aderr

#define c_erreur(ier) { extern struct error error_;\
	error_.retadr = (int(*)())-1; ier = setjmp(error_.retenv); }
#define silent_err() { extern struct error error_;\
	error_.silent = 1;}
#define abort_err() { extern struct error error_;\
	error_.retadr = (int(*)())0;}
