/*
 * Local definitions of INRIMAGE
 */

#ifndef INRLOCAL_INCLUDED
#define INRLOCAL_INCLUDED

#include <errno.h>

/* 
 * Image formats natively supported by Inrimage :
 *   - Visilog-1
 *   - old-inrimage (obsolete format)
 *   - Inrimage-3 (format with binary header)
 *   - Inrimage-4 (recommended format, with ascii header)
 *
 * @TODO : use switches in configure to enable/disable these supports.
 * Uncomment following lines to disable some of them :
 */

/* disable Visilog-1 */
/*#define NO_VISILOG */  

/* disable Inrimage-3 */
/*#define NO_INR3 */  

/* disable Inrimage-4 (not recommanded !) */
/*#define NO_INR4 */ 

/* define INR_KHOROS if you want to enable khoros mode for options 
(inr_init.c igetopt.c) */
#define INR_KHOROS


/* 
 * Configuration for inr_init.c (for kdopts()_) 
 */
 
/* Environment variable for default memory allocation in Kbytes (see option -k) */
#define INR_DEFK "INR_KBMEM"

/* Default mem size in Kbytes if no -k option and no INR_DEFK in environment */
#ifdef __ksr1__
#define DEF_KBMEM 1000
#else
#ifdef linux
#define DEF_KBMEM 4000
#else
#ifdef __alpha
#define DEF_KBMEM 500
#else
#define DEF_KBMEM 300
#endif
#endif
#endif
/* end config kdopts_() */

/*
 * Following defines are only used in inropts.c 
 */

/* Default inrimage home dir 
   datarootdir=${prefix}/share
   prefix=/usr/local
 */
// # define INR_DEF_HOME "${prefix}/share/inrimage"
# define INR_DEF_HOME "/usr/local/share/inrimage"
/* INR_DEF_HOME2 alternate path for root dir used only by bin-src/kitext.c */
# define INR_DEF_HOME2 "/usr/local/share/inrimage"
/* Alternate dir for INR_CTRL_FILE (default inr_home) */
# define INR_CTRL_XDIR INR_DEF_HOME
/* Name of env. variable for INR_HOME */
#define ENV_INR_HOME "INR_HOME"
/* Dir inr inr_home for inr_extfile & Inrimage4.conf */
#define INR_CONFDIR "etc"  
/* Conf dir in user homedir : for inr_extfile, Inrimage4.conf */
#define USER_INR ".inrimage"   
#define INR_CTRL_FILE "Inrimage4.conf"
/* Default Inrimage header : 4 blocks of 256 bytes */
#define DEF_HDR4BLK 4  
/* Default INR3 header : 1 block of 256 bytes  */
#define DEF_HDR3BLK 1  
/* Max size of header */
#define DEF_MAXHDRBLK 16  
/* Default header version */
#define DEF_VERS IV_INR4  
#define DEF_HISTORY 0

/* 
 * Names of some environment variables 
 */
#define ENV_VERS "IMAGE_OUT"
#define ENV_HDR "IMAGE_HDRL"
#define ENV_HIST "IMAGE_HIST"
 
/* 
 * Names of file formats 
 */
#define NOM_OLD "Old"
#define NOM_INR3 "Inr3"
#define NOM_INR4 "Inrimage"
#define NOM_VLOG "Visilog1"

/*
 * Environment variable name for INR_EXTFILE 
 */
#define ENV_INR_EXTFILE "INR_EXTFILE"

/* 
 * Name of the file containing the list of converters 
 */
#define INR_EXTFILENAME "inr_extfile"

#endif   /* INRLOCAL_INCLUDED */
