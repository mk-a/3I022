/* types de flottants repertories */
#define FL_UNDEF 0
#define FL_PE 0x101
#define FL_GOULD 0x102
#define FL_SUN 0x103
#define FL_HACKERS 0x104
#define FL_VAX 0x105
#define FL_DEC 0x106
#define FL_KSR1 0x107
#define FLT_32 1
#define FLT_64 2

struct fltcnv {
	int v_moins1;
	char fl_msbfirst; /* 1 if MSB first */
	char fl_sizes;  /* flags indiquant si existe flottant 32 et 64 bits */
	short fl_typ;
	char *fl_name;	/* string du nom du type */
};

extern int Ismsb_val;
#define ISMSBFIRST (*(char *) &Ismsb_val)
