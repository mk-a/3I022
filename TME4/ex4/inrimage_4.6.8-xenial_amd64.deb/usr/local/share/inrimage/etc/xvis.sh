## cliquer sur une ligne ##!SELECT ou ##!BEGIN
##  pour selectionner un module
###
##!SELECT extract-bw extraction d'une sous-image N&B
##!SELECT extract-col extraction d'une sous-image couleur
##!SELECT ifmt-getct  extraction table couleur d'une image
##!SELECT histo affichage d'histogramme (avec gnuplot)
##!SELECT profil-hor profil horizontal du centre de la boite de selection (avec gnuplot)
##!SELECT profil-ver profil vertical du centre de la boite de selection (avec gnuplot)
##!SELECT eg egalisation d'histogramme
##!SELECT norma normalisation
##!SELECT cnvcol passage de 3 images a 1 image couleur 3 plans 
##!SELECT im-ps  PostScript N&B d'une image
##!SELECT subimag-ps  PostScript N&B d'une sous-image
##!SELECT graphic-ex1 exemple de graphique en couleur
##!SELECT draw-cercle trac� de cercles
##!SELECT draw-rect trac� de rectangles
##!SELECT draw-ncercle trac� de cercles dans tous les plans
# 
##!BEGIN-sh extract-bw extraction d'une sous-image N&B
ext $im -ix $x0 -iy $y0 -iz $z0 -x $dx -y $dy -z $dz >$im.ext && xvis $im.ext&
##!BEGIN-sh extract-col extraction d'une sous-image couleur
xx0=`expr \( $x0 - 1 \) \* $ndimv + 1`
ext $im -ix $xx0 -iy $y0 -iz $z0 -x $dx -y $dy -z $dz -v $ndimv >$im.ext && xvis $im.ext&
##!END
##!BEGIN-sh ifmt-getct  extraction table couleur d'une image
ifmt $im -getct $im.tc 
##!END
###########################################################
##!BEGIN-sh histo
his $im | tpr -c -l 1 > $im.his
echo "
plot '$im.his' with histograms
pause 1000
" > /tmp/xvis$$ ; gnuplot /tmp/xvis$$ &
rm -f /tmp/xvis$$
##!END
############################################################
##!BEGIN-sh profil-hor
tpr $im -l 1 -c -y 1 -iy `expr \( $y0 + $y1 \) / 2` > $im.ph
echo "
plot '$im.ph' with lines
pause 1000
" > /tmp/xvis$$ ; gnuplot /tmp/xvis$$ &
rm -f /tmp/xvis$$
##!END
###########################################################
##!BEGIN-sh profil-ver
tpr $im -l 1 -c -x 1 -ix `expr \( $x0 + $x1 \) / 2` > $im.ph
echo "
plot '$im.ph' with lines
pause 1000
" > /tmp/xvis$$ ; gnuplot /tmp/xvis$$ &
rm -f /tmp/xvis$$
##!END
############################################################
##!BEGIN-sh eg egalisation d'histogramme
eg $im >$im.eg && xvis $im.eg&
##!BEGIN-sh norma normalisation
norma $im >$im.n && xvis $im.n&
##!END
########################################
#  images couleur
##!BEGIN-csh cnvcol passage de 3 images a 1 image couleur 3 plans 
set out=$im; cnvcol -crgb $imr $img $imb >$out:r.rgb
##!BEGIN-sh im-ps  PostScript N&B d'une image
cnvcol -bw $im | im2ps -x c -y c >$im.ps
##!BEGIN-sh subimag-ps  PostScript N&B d'une sous-image
cnvcol -bw $im | ext -ix $x0 -iy $y0 -x $dx -y $dy | im2ps -x c -y c >$im.ps
############################################################
##!BEGIN-sh graphic-ex exemple de graphique en couleur
##!params(exp 1)
##!re-read
##!ct_interp(rgb,0 0 0,0 0 0,128 128 128, 255 255 255)
##!ct_set(rgb,129 129 129,255 0 0)
##!ct_set(rgb,130 130 130,0 255 0)
>|xvisdraw -c 129 <<%
1 1
32 1
32 32
1 32
1 1
%
xvisdraw -c 130 <<%
1 1
20 1
20 20
1 20
1 1
%
##!BEGIN draw-cercle trac� de cercle dans la boite
##!nobox
##!draw(z $z0,a $x0 $y0 $dx $dy)
##!BEGIN draw-rect trac� de rectangles
##!nobox
##!draw(z $z0,L $x0 $y0 $x1 $y0 $x1 $y1 $x0 $y1 $x0 $y0)
##!BEGIN-perl draw-ncercle trac� de cercles dans tous les plans
>|
$|=1;
print "##!nobox\n";
$j = $z0;
for($i=0;$i<$dz;$i++) {
print "##!draw(z $j,a $x0 $y0 $dx $dy)\n";
$j++;
}
### end 
