# Suite de tests Inrimage


CFLAGS  = `inrinfo --cflags`
LDFLAGS = 
LDLIBS  = `inrinfo --libs`
CC	= x86_64-linux-gnu-gcc
FC      = gfortran

IMAGE = ../xvis-demo/fille.b.gz

all: res_sc1.inr res_sc2.inr res_sc3.inr res_sc4.inr \
     res_1o.inr res_flt.inr res_bin.inr

res_sc1.inr: scale1
	./$< $(IMAGE) -sc 0.7 $@
res_sc2.inr: scale2
	./$< $(IMAGE) -sc 0.7 $@
res_sc3.inr: scale3
	./$< $(IMAGE) -sc 0.7 $@
res_sc4.inr: scale4
	./$< $(IMAGE) -sc 0.7 $@
res_1o.inr: thresh_1o
	./$< $(IMAGE) -n 128 $@
res_flt.inr: thresh_flt
	./$< $(IMAGE) -n 0.5 $@
res_bin.inr: thresh_bin
	./$< $(IMAGE) -n 0.5 $@

scale1: main.o verysimple_scale.o
	$(CC) $^ -o $@ $(LDLIBS) $(LDFLAGS) 
scale2: main.o simple_scale.o
	$(CC) $^ -o $@ $(LDLIBS) $(LDFLAGS) 
scale3: main.o scale.o
	$(CC) $^ -o $@ $(LDLIBS) $(LDFLAGS) 
scale4: fmain.o fcmain.o simple_scale.o
	$(FC) $^ -o $@ -linrfort $(LDLIBS) $(LDFLAGS)  

clean:
	$(RM) scale1 scale2 scale3 scale4 thresh_1o thresh_flt thresh_bin
	$(RM) *.o
	$(RM) res_*.inr

