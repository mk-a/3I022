/* exemple simple de main C pour inrimage */
/* programme qui multiplie une image de codage quelconque
avec resultat dans une image en flottant.
Par defaut coef=1, lecture stdin, ecriture stdout
*/

#include <inrimage/image.h>

static char Ucmd[]=
"[-D] [-k nb_Ko] [-sc scale] [input | -] [output]";
static char Udetail[]=
"\tmultiplication d'image par constante\n\
\t-sc : coefficient flottant (1 par defaut).\n\
\tinput : image source, de codage quelconque( stdin si '-')\n\
\toutput : image resultat, de codage flottant( stdout si absent)";


static float scale= 1.;

main(argc,argv)
int argc;
char **argv;
{
	char in[256], out[256];

	inr_init(argc,argv,"1.0-beta",Ucmd,Udetail);

	/* chercher option -sc a 1 arg. */
	igetopt1("-sc","%f",&scale);

	/* chercher fichiers entree et sortie */
	infileopt(in);
	outfileopt(out);

	/* verif d'utilisation correcte des options */
	if(tstopts()) /* s'il reste des options : exit avec message */
		iusage_(Ucmd,Udetail); 

	/* appel du programme qui va ouvrir les images et allouer la memoire */
	call_scale(in,out,scale);
	/* ne pas oublier return  pour que l'exit-code  de la commande
	   soit defini */
	return 0;   
}
