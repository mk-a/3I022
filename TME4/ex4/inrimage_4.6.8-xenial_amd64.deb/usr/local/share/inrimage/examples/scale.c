#include <stdio.h>
#include <inrimage/image.h>

extern int debug_; /* non d�finie dans image.h */

static void do_scale();

call_scale(in,out,scale)
char *in, *out;
float scale;
{
	struct image *nfi, *nfo;
	Fort_int lfmti[9], lfmto[9];
	float lscale;
	Fort_int nbfix, nbvar, idimf, ipoids;
	Fort_int ier;
	register i;

	nfi = image_(in,"e","",lfmti);

	/* l'utilisation de 2 tableaux lfmt est faite a titre de demonstration */
	for(i=0;i<9;i++)
		lfmto[i] = lfmti[i];
	lfmto[I_TYPE] = REELLE;
	lfmto[I_BSIZE] = sizeof(float);

	/* l'image resultat doit avoir un format correct :
	   meme taille que input et codage flottant */
	nfo = image_(out,"s","a",lfmto);

	/* on a besoin d'un seul buffer de travail, donc de poids 1 */
	nbfix = 0;
	idimf = 0;
	nbvar = 1;
	ipoids = 1;
	lscale = scale;
	/* passage d'arg par adresse */
	exec_(&ier,&nbfix,&idimf,&nbvar,&ipoids,do_scale,&nfi,&nfo,lfmto,&lscale,&ier);
	if(ier != 0)
		fprintf(stderr,"error in do_scale\n");

	fermnf_(&nfi);
	fermnf_(&nfo);

}


void do_scale(buffer,ndim,pnfi,pnfo,lfmt,scale)
float *buffer;
Fort_int *ndim, *lfmt;
struct image **pnfi, **pnfo;
float *scale;
{
	Fort_int nblig;  /* nb lignes par bloc */
	Fort_int reste;  /* nb lignes dernier bloc */
	Fort_int size;  /* nb points dans 1er bloc */
	Fort_int npts, ntot;

	/* on calcule combien de lignes d'image on peut traiter a la fois */
	setup_(ndim,lfmt,&nblig,&reste,&size);

	nblig = size / (DIMX * sizeof(float));
	if(nblig <= 0)
		imerror(8,"pas assez de memoire\n");

	/* on traite par blocs */
	ntot = DIMY;
	npts = nblig * DIMX;
	while(ntot > 0) {
		if(nblig > ntot) {
			nblig = ntot;
			npts = nblig * DIMX;
		}
		/* on lit en convertissant en flottant */
		c_lecflt(*pnfi,nblig,buffer);
		
		if( *scale != 1.)
			scale_buf(buffer,buffer,npts,*scale);

		c_ecr(*pnfo,nblig,buffer);
		
		ntot -= nblig;
	}
}

scale_buf(ibuf,obuf,n,scale)
register float *ibuf, *obuf;
register n;
register float scale;
{
	if(debug_)
		fprintf(stderr,"scaling %d points with %f\n",n,scale);
	while(n-- > 0)
		*obuf++ = scale * *ibuf++;
}
