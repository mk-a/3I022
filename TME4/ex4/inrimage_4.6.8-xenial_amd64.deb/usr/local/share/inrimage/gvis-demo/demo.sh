#! /bin/sh

mkdir /tmp/gvis-demo
cp * /tmp/gvis-demo
cp ../xvis-demo/im.3D.gz /tmp/gvis-demo
cd /tmp/gvis-demo
make -f Makefile.ex

echo "Affichage de tampon image dans une fen�tre depuis un programme C"
./demo-window

echo "Affichage d'image INRIMAGE dans un programme GTK+"
./demo-widget im.3D.gz
cd ..
rm -rf gvis-demo

