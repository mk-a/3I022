/**
 * Exemple d'utilisation GVIS depuis un programme C
 * (c) 2007 Dominique Bereziat
 */

#include <inrimage/gvis.h>


int main( int argc, char **argv) {
  Fort_int lfmt[9];
  unsigned char *buf;
  int i,j;

  inr_init( argc, argv, "1.0.0", "",
	    "Exemple d'affichage gvis dans un programme C");


  /* cr�er un tampon 256 x 256 et un format inrimage associ� */
  NDIMX = NDIMY = 256;
  NDIMV = NDIMZ = 1;
  EXP = 200; BSIZE = 1; TYPE = FIXE;
  DIMX = NDIMX;
  DIMY = NDIMY;
  
  buf = (unsigned char*)i_malloc( buffer_size( lfmt, 256));

  for( j=0; j<NDIMY; j++)
    for( i=0; i<NDIMX; i++)
      if( i == j )
	buf[i+NDIMX*j] = 255;
      else
	buf[i+NDIMX*j] = 0;

  /* modifier lfmt -> buf ne contient qu'un plan */
  NDIMZ = 1; DIMY = NDIMY;

  gvis_fork( buf, lfmt);

  for( j=0; j<NDIMY; j++)
    for( i=0; i<NDIMX; i++)
      if( NDIMX - i == j )
	buf[i+NDIMX*j] = 255;  
  gvis_show( buf, lfmt, 0);
  gvis_event();
 
  return 0;
}
