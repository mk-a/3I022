# Exemple de Makefile pour compiler
# des programmes clients de gvis

CFLAGS  = `inrinfo gvis --cflags` 
LDFLAGS = 
LDLIBS  = `inrinfo gvis --libs`
all: demo-window demo-widget
clean:
	$(RM) demo-window demo-widget

