##!# demo 1 : dessiner une boite qui grandit
##!upleft()
##!params(pas 1)
##!ct_map(grey)
##!re-read(fille.b.gz)
>|p0=100;p1=140
while [ $p0 -gt 0 ]
do
	echo "##!box($p0,$p0,1,1,$p1,$p1,1,1)"
	echo "##!invert"
	p0=`expr $p0 - 16`
	p1=`expr $p1 + 16`
done
##!
##!#  demo 2 : boite determinee par 2 points :
##!# cliquer sur 2 points avec MiddleButton
##!pause
##!box(8,8,1,1,408,30,1,1)
##!ct_set(rgb,2 2 2,255 0 0)
##!texte(2,cliquer sur 2 points avec MiddleButton)
##!nobox
|>| xx=`head -2 | tr '\012' ' '`
yy=`echo "$xx" | sed 's/ /,/g'`
echo "##!box($yy)"
echo "##!fill(2)"
##!
##!# demo 3 : affichage des plans d'une image multiplan
##!pause
##!params(pas 1,iz 1,nz 5)
##!re-read(im.3D.gz)
>|i=1
while [ $i -le 5 ]
do
	echo "##!upleft(1,1,$i)"
	echo "##!pause(1)"
	i=`expr $i + 1`
done
##!upleft
##!ct_set(rgb,0 0 0,255 0 0)
##!ct_set(rgb,2 2 2,255 0 255)
##!box(60,60,1,1,130,100,3,1)
##!texte(2,echographie)
##!
##!#  tables random
##!pause
##!ct_map(random)
>|i=0
while [  $i -lt 8 ]
do
	echo "##!ct_map(random+)"
	i=`expr $i + 1`
done
##!# demo : recuperation de dump par pipe
##!pause
##!ct_map(grey)
##!upleft
##!params(pas 1)
##!re-read(fille.b.gz)
##!box(335,25,1,1,478,130,1,1)
|>|echo "##!dump(>)"
sc -n 1.4 | cco -f >yy64
##!pause
##!params(pas 1)
##!re-read(yy64)
##!nobox
##!ct_map(grey)
##!ct_set(rgb,0 0 0,255 0 230)
##!ct_set(rgb,255 255 255,195 255 255)
##!
##!# demo : remplissage de zones
##!pause
/bin/rm -f yy64;raz yy64 -x 64 -y 64
##!params(pas -2)
##!re-read(yy64)
##!nobox
##!clear
##!ct_map(table1)
##!box(2,2,1,1,60,60,1,1)
##!fill(138)
##!box(2,2,1,1,15,15,1,1)
##!fill(11)
##!box(2,45,1,1,15,58,1,1)
##!fill(199)
##!box(45,2,1,58,15,1)
##!fill(87)
##!box(45,45,1,1,58,58,1,1)
##!fill(235)
##!box(24,5,1,1,38,14,1,1)
##!texte(5,HELLO)
##!box(18,20,1,1,42,42,1,1)
>|i=0
while [ $i -lt 255 ]
do
	echo "##!fill($i)"
	i=`expr $i + 15`
done
