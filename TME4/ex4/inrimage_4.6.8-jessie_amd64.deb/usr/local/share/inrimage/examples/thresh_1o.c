/**
 * Test 1 : lecture, seuillage puis �criture en 1 octet.
 */

#include <assert.h>
#include <inrimage/image.h>

int main(int argc, char **argv) {
  struct image *img;
  char nom[256];
  unsigned char *buf;
  Fort_int lfmt[9];
		     
  int i,j,val = 128;
  
  inr_init(argc,argv,"","","");
  igetopt1( "-n", "%d", &val);

  infileopt(nom);
  img = image_( nom, "e", "", (void*)lfmt);
  
  assert( BSIZE == 1);
  assert( TYPE == FIXE);

  buf = (unsigned char *)i_malloc(DIMX*DIMY);
  c_lect( img, DIMY, (void*)buf);
  fermnf_( (void*)&img);

  for(j=0;j<DIMY;j++)  
    for(i=0;i<DIMX;i++)
      buf[i+DIMX*j] = ( buf[i+DIMX*j] < val) ? 0 : 255;
  
  outfileopt(nom);
  img = image_( nom, "c", "", (void*)lfmt);
  c_ecr( img, DIMY, (void*)buf);
  fermnf_( (void*)&img);
  return 0;
}

