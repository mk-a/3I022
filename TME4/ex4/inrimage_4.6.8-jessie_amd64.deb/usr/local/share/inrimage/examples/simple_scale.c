#include <stdio.h>
#include <inrimage/image.h>

/* non d�finie dans image.h */
extern int debug_;
extern int koctet_;
#define DEFAULT_KO 300

call_scale(in,out,scale)
char *in, *out;
float scale;
{
	struct image *nfi, *nfo;
	Fort_int lfmt[9];
	char *buffer;
	int npts, n;
	int size, nblig, ntot;

	nfi = image_(in,"e","",lfmt);
	TYPE = REELLE;
	BSIZE = sizeof(float);
	/* l'image resultat doit avoir un format correct :
	   meme taille que input et codage flottant */
	nfo = image_(out,"s","a",lfmt);

	/* allocation d'un buffer de travail */
	n = DIMX * DIMY * sizeof(float);
	if(koctet_ <= 0)
		koctet_ = DEFAULT_KO;
	size = koctet_ * 1024;
	if(size > n)
		size = n;  /* inutile d'allouer plus que necessaire */
	buffer = i_malloc(size);

	/* on calcule combien de lignes d'image on peut traiter a la fois */
	nblig = size / (DIMX * sizeof(float));
	if(nblig <= 0)
		imerror(8,"pas assez de memoire\n");

	/* on traite par blocs */
	ntot = DIMY;
	npts = nblig * DIMX;
	while(ntot > 0) {
		if(nblig > ntot) {
			nblig = ntot;
			npts = nblig * DIMX;
		}
		/* on lit en convertissant en flottant */
		c_lecflt(nfi,nblig,buffer);

		if(scale != 1.)
			scale_buf(buffer,buffer,npts,scale);

		c_ecr(nfo,nblig,buffer);
		
		ntot -= nblig;
	}

	fermnf_(&nfi);
	fermnf_(&nfo);
	i_Free(&buffer);
}

scale_buf(ibuf,obuf,n,scale)
register float *ibuf, *obuf;
register n;
register float scale;
{
	if(debug_)
		fprintf(stderr,"scaling %d points with %f\n",n,scale);
	while(n-- > 0)
		*obuf++ = scale * *ibuf++;
}
