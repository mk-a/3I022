#include <stdio.h>
#include <inrimage/image.h>

/* non d�fini dans image.h */
extern int debug_;

call_scale(in,out,scale)
char *in, *out;
float scale;
{
	struct image *nfi, *nfo;
	Fort_int lfmt[9];
	char *buffer;
	int npts;
	nfi = image_(in,"e","",lfmt);
	TYPE = REELLE;
	BSIZE = sizeof(float);
	/* l'image resultat doit avoir un format correct :
	   meme taille que input et codage flottant */
	nfo = image_(out,"s","a",lfmt);
	npts = DIMX * DIMY;
	buffer = i_malloc(npts * sizeof(float));

	/* on lit en convertissant en flottant */
	c_lecflt(nfi,DIMY,buffer);

	if(scale != 1.)
		scale_buf(buffer,buffer,npts,scale);

	c_ecr(nfo,DIMY,buffer);

	fermnf_(&nfi);
	fermnf_(&nfo);
	i_Free(&buffer);
}

scale_buf(ibuf,obuf,n,scale)
register float *ibuf, *obuf;
register n;
register float scale;
{
	if(debug_)
		fprintf(stderr,"scaling %d points with %f\n",n,scale);
	while(n-- > 0)
		*obuf++ = scale * *ibuf++;
}
