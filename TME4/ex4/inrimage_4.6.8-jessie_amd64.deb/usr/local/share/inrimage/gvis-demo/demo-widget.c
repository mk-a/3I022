/**
 * Exemple d'utilisation du widget GVIS dans GTK+
 * (c) 2007 Dominique Bereziat
 */

#include <inrimage/gvis.h>

float *buf, *thresh;
Fort_int lfmt[9];

void on_thresh_changed (GtkRange *range,
			    gpointer  user_data) {
  gdouble value = gtk_range_get_value( GTK_RANGE(range));
  gvisapi *gvis = user_data;
  inrgvis *img  = gvis_inrgvis( gvis);
  long count;

  /* seuillage */
  for( count = DIMX*DIMY; count >0; count --)
    thresh[count] = buf[count] > value ? buf[count] : 1;
  
  inrgvis_rrbuf( img, thresh, TRUE);
  gvis_refresh( gvis);
}

int gtk_widget_get_height( GtkWidget *widget) {
  GtkRequisition req;
  gtk_widget_size_request( widget, &req);
  return req.height;
}

int main( int argc, char **argv) {
  GtkWidget *root, *widget, *child;
  gvisapi  *gvis;
  int width, height, h;
  struct image *nf;
  char nom[128];

  inrgvis *data;


  inr_init( argc, argv, "1.0.0", "", "Affichage d'image dans GTK+");
  gtk_init( &argc, &argv);


  /* construction de ma fen�tre */
  root = widget = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_show( widget);
 
  child = gtk_vbox_new( FALSE, 0);
  gtk_container_add( GTK_CONTAINER(widget), child);
  gtk_widget_show( child);
  widget = child;

  child = gtk_label_new( "Seuillage d'image");
  gtk_widget_show( child);
  height = gtk_widget_get_height(child);
  gtk_box_pack_start( GTK_BOX( widget), child, FALSE, FALSE, 0);

  /* widget gvis */
  child = gtk_gvis_new( 0);
  gtk_widget_show( child);

  gtk_box_pack_start( GTK_BOX( widget), child, TRUE, TRUE, 0);
  gvis = gtk_gvis_api( child);

  /* parametre de seuillage */
  child = gtk_hscale_new_with_range( 0, 1, 0.01);
  gtk_widget_show( child);
  height += gtk_widget_get_height(child);
  gtk_box_pack_start( GTK_BOX( widget), child, FALSE, FALSE, 0);
  g_signal_connect( (gpointer) child, "value-changed", 
		    G_CALLBACK(on_thresh_changed), gvis);
  gtk_range_set_update_policy( GTK_RANGE(child), GTK_UPDATE_DELAYED);

  child = gtk_hbutton_box_new();
  gtk_widget_show( child);
  gtk_box_pack_end( GTK_BOX( widget), child, FALSE, FALSE, 0);
  widget = child;
  
  child = gtk_button_new_with_label( "Fermer");
  gtk_widget_show( child);
  height += gtk_widget_get_height(child);
  gtk_box_pack_end( GTK_BOX( widget), child, TRUE, TRUE, 0);
  g_signal_connect( (gpointer) child, "clicked", G_CALLBACK(gtk_main_quit), NULL);

  /* fin interface */

  /* chargement de l'image */
  infileopt( nom);
  nf = image_( nom, "e", "", (NF_fmt*)lfmt);
  buf = (float *)i_malloc( sizeof(float)*DIMX*DIMY);
  c_lecflt( nf, DIMY, (void*)buf);
  fermnf_ ( &nf);
  
  /* donn�es au format gvis */
  TYPE = REELLE; BSIZE = sizeof(float);
  data = inrgvis_rbuf( buf, lfmt, TRUE);

  gvis_attach( gvis, data);
  gvis_get_size( gvis, &width, &h);
  
  gtk_window_resize( GTK_WINDOW(root), width, height+h);

  thresh = (float *)i_malloc( sizeof(float)*DIMX*DIMY);

  gtk_main();

  i_Free( (void*)&buf);
  return 0;
}
