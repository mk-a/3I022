/*
 * Fork de inrshell 0.2.2
 */

#include <inrimage/image.h>
#include <gtk/gtk.h>

#ifndef VERSION
#define VERSION "1.1.0"
#endif

/**
 * @page gvisintro Documentation de la librairie libgvis
 *
 * (Manuel unix de cette page : <tt>man gvisintro</tt>)
 *
 * @section intro Pr�sentation
 *
 * Libgvis est une extension d'Inrimage qui vous permet d'afficher des tampons
 * images (l'image est d�crite par un tampon et un tableau de format) dans une
 * fen�tre GTK. Cette librairie est donc une alternative � la m�thode qui
 * consiste � faire un dump du tampon sur le disque, et � afficher l'image
 * avec un visualisateur Inrimage � l'aide d'un appel syst�me (ou de forcer
 * une relecture en envoyant un signal).
 * Enfin, tout type de tampon est support� par libgvis.
 *
 * Le visualisateur l�ger d'Inrimage, <a href="../gvis.1i.html">gvis</a>, utilise 
 * directement cette librairie.
 *
 * @section str Structure de la librairie
 *
 * La librairie offre se compose de trois parties.
 *
 * @subsection s2 Appels haut niveaux
 * Ce sont des fonctions qui affichent directement
 * des tampons images dans des fen�tres GTK.
 *   - manuel unix : <tt>man gvis2</tt>
 *   - manuel html : \ref gvis2
 * 
 * @subsection s1 Appels bas niveaux
 * Ces fonctions fournissent un widget GTK 'gvis' qui
 * peut �tre utilis�s directement par des programmes GTK. Dans ce widget
 * est affich� l'image ainsi que d'optionnels contr�les sur l'image.
 *   - manuel unix : <tt>man gvis1</tt>
 *   - manuel html : \ref gvis1
 *
 * @subsection io Routines de lectures et conversions
 * Ces fonctions lisent des fichiers images sur le disque ou
 * convertissent des tampons images au format �cran, c'est-�-dire
 * un format affichable par GDK.
 *   - manuel unix : <tt>man inrgvis</tt>
 *   - manuel html : \ref inrgvis
 * 
 *
 * On trouvera quelques exemples d'utilisation des deux couches de la librairie
 * dans le r�pertoire <tt>$prefix/share/inrimage/gvis-demo</tt>.
 */

/**
 * @defgroup libgvis libgvis
 * @brief Routines d'affichage d'images dans une fen�tre GTK.
 */

/** @addtogroup libgvis
 * @{ */
/**
 * @defgroup inrgvis inrgvis
 * @brief Manipulation d'image INRIMAGE au format GVIS.
 *
 * Toutes images sur le disque ou en m�moire doivent �tre converties
 * dans un format admissible par GTK+ (c'est-�-dire un codage sur
 * 1 octet et une organisation plan/vecteur ad�quat). Ces routines
 * font ce travail.
 */

/**
 * @defgroup gvis1 gvis1
 * @brief Routines d'affichage GVIS bas niveau
 */

/**
 * @defgroup gvis2 gvis2
 * @brief Routines d'affichage GVIS depuis un programme client.
 */
/** @} */

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

/** @addtogroup inrgvis
 * @{ */

typedef unsigned char uchar;
typedef void inrgvis;

inrgvis*  inrgvis_load( char *nom, int xvis, void (*progress)(char fmt[], ...));
void      inrgvis_free( inrgvis* data);
inrgvis*  inrgvis_next( inrgvis* data);
inrgvis*  inrgvis_prev( inrgvis* data);
void      inrgvis_set_threshold( float thresh);
inrgvis*  inrgvis_rbuf ( void* buf, Fort_int lfmt[], int xvis);
inrgvis*  inrgvis_rrbuf( inrgvis* data, void* buf, int xvis);
Fort_int* inrgvis_get_lfmt  ( inrgvis* data);
uchar*    inrgvis_get_buffer( inrgvis* data);
/** @} */

/* 
 * Interface api.c
 */

typedef GHashTable gvisapi;

/** @addtogroup gvis1
 * @{ */

#define GVIS_WIDGET_TOOLBAR   0x1
#define GVIS_WIDGET_STATUSBAR 0x2
#define GVIS_BUFFER_FLOAT     0x4
#define GVIS_DISPLAY_XVIS     0x8
#define GVIS_DISPLAY_NORGB    0x10
#define GVIS_ADJUST_TITLE     0x20
#define GVIS_ADJUST_SIZE      0x40

GtkWidget* gtk_gvis_new  ( int mode);
gvisapi*   gtk_gvis_api  ( GtkWidget *widget);
inrgvis*   gvis_inrgvis  ( gvisapi *gvis);

void       gvis_keymap   ( gvisapi *gvis);

void       gvis_attach   ( gvisapi *gvis, inrgvis* image);
#define    gtk_gvis_attach(wid,img)  gvis_attach(gtk_gvis_api(wid),img)
void       gvis_unattach ( gvisapi *gvis);
void       gvis_delete   ( gvisapi *gvis);
void       gvis_get_size ( gvisapi *gvis, int *w, int *h);
#define    gtk_gvis_get_size(wid,w,h)  gvis_get_size(gtk_gvis_api(wid),w,h)
void       gvis_window_adjust( gvisapi *gvis, int flags);
void       gvis_refresh  ( gvisapi *api);

void       gvis_set_frame( gvisapi *gvis, int iz);
void       gvis_next_frame( gvisapi *gvis);
void       gvis_prev_frame( gvisapi *gvis);

void       gvis_set_component( gvisapi *gvis, int iv);
void       gvis_next_component( gvisapi *gvis);
void       gvis_prev_component( gvisapi *gvis);

void       gvis_set_zloop_time ( gvisapi *gvis, int timer);
void       gvis_set_zloop_pause( gvisapi *gvis);
void       gvis_set_vloop_time ( gvisapi *gvis, int timer);
void       gvis_set_vloop_pause( gvisapi *gvis);

/** @} */

/** @addtogroup gvis2
 * @{ */
gvisapi   *gvis_show   ( void *buf, Fort_int lfmt[], int mode);
void       gvis_event  ( void);
void       gvis_fork   ( void *buf, Fort_int lfmt[]);
gvisapi   *gvis_thread ( void *buf, Fort_int lfmt[]);
/** @} */
