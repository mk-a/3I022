#define TEK_SIZE 4096
#define INCH_PTS 72.
#define INCH_MM 25.4

struct paper {
	float width, height;
};

/* modes de trace */
#define I_NORM 0
#define I_DOT 1
#define I_D_DASH 2
#define I_SHORTDASH 3
#define I_LONGDASH 4

/* retours en mode alpha : Return, ESC FF, US */ 
/* codes de la tek */
#define ESC 0x1b
#define FF 0xc
#define GS 0x1d
#define US 0x1f
#define FS 0x1c
#define T_POINT FS
/* esc sequences */
#define T_ERASE FF
#define T_SIZ1 ';'
#define T_SIZ2 ':'
#define T_SIZ3 '9'
#define T_SIZ4 '8'
#define T_DOT  'a'
#define T_NORM '`'
#define T_D_DASH 'b'
#define T_SHORTDASH 'c'
#define T_LONGDASH 'd'

#define T_MASKV 0x1f  /* bits de data */
#define T_MASKH 0x60
#define T_HXY 0x20
#define T_LBY 0x60
#define T_LX 0x40
