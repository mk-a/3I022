#ifndef INR_dialog_included   /* ignore if already included */
#define INR_dialog_included


#include <inrimage/image.h>

struct cmdtab {
	char *cmd;
	short nbmin;   /* nb min de char. de la commande */
	int ret_val;   /* return value. 0 = on retourne le numero cmde >= 1 */
};

/*
   COMMON /CODCAR/ IBRK,IRETC,ILF,IBELL,ICTRA,ICTRB,ICTRC,IBLAN
     1,IBACK,IPV,IDOLL,IADS,IEXCL,INFR,ISLSH,IPLUS,IMOINS,ISTAR
     2,IEGAL,IPOINT,I2P,IC0,IC9,ICA,ICZ,ICPA,ICPZ,IPTI,MBCK,NCRLF
*/
struct codcar {
	char ibrk[4];
	Fort_int iretc;
	Fort_int ilf;
	Fort_int ibell;
	Fort_int delchar;
	Fort_int delword;
	Fort_int exit;
	Fort_int iblan;
	Fort_int iback;
	Fort_int ipv, idoll, iads, iexcl, infr, islsh, iplus;
	Fort_int imoins, istar, iegal, ipoint, i2p, ic0, ic9, ica, icz;
	Fort_int icpa, icpz, ipti, mbck, ncrlf;
};

/*
COMMON /DIALG/ NBCHR,NUMBRK,ICRBRK,LIGBUF(21),ISTPTI,IFLMIN
*/
struct dialg {
	int nbchr; /* nb char du dernier ltchai */
	int numbrk; /* numero du break >= 1 */
	int icrbrk;  /* le break trouve */
	char lignuf[82];
	int istpti;   /* mis a 1 par iquel si cmde terminee par '?' */
	int iflmin;
};
/*
COMMON/MMACRO/IMAC(38),MRKCD,IRES(3),ITBETQ(48),ITABVD(300),
     !ILGMAC(7),NMMAC(21),MACRF(3)
*/
struct mmacro {
	short imac[38];
	int mrkcd;
	int ires[3];
	int itbetq[48];
	int itabvd[300];
	short ilgmac[7];
	short nmmac[21];
	int macrf[3];
};

#endif /* INR_dialog_included */
