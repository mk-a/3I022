TME 4 - ADRIEN MAINKA 3407003

Les réponses des questions nécessitants des commandes sont écrites dans des script.sh éponymes.

Les autres réponses aux questions sont écrites ici:



EXERCICE 1:

Question 1:

On remarque que plus le filtre guassien est grand plus l'image traitée est floutée.



EXERCICE 2:

Question 1:

On remarque que plus le filtre gaussien est grand moins l'image filtrée est détaillée, et moins il y ade bruit.

Question 2:

On remarque que les filtres médians et gaussiens sont des moyens de débruiter une image.
